<?php 
session_start();
include 'db_connection.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PayPal Sandbox Payment</title>
    <script src="https://www.paypal.com/sdk/js?client-id=AaBLxhzRIQR8U9guxYiDu3qF0ldRs-asz9wcAaOpEonHqOjMA4K4KOLD2FtJxH7ANK3aKzWfoH3ricSN&currency=USD"></script> 
</head>
<body>
    <h1>Service Payment (Sandbox Mode)</h1>

    <form id="payment-form">
        <label for="account_id">Service Provider PayPal Email:</label>
        <input type="email" id="account_id" name="account_id" required>
        <br><br>

        <label for="amount">Payment Amount (USD):</label>
        <input type="number" id="amount" name="amount" min="1" step="0.01" required>
        <br><br>

        <div id="paypal-button-container"></div> 
    </form>

    <script>
        paypal.Buttons({
            createOrder: function(data, actions) {
                const accountID = document.getElementById('account_id').value.trim();
                let totalAmount = parseFloat(document.getElementById('amount').value);

                if (!accountID || isNaN(totalAmount) || totalAmount <= 0) {
                    alert('Invalid input: Check PayPal Email and Amount.');
                    return actions.reject();
                }

                // Calculate platform fee and provider amount
                const platformFee = (totalAmount * 0.06).toFixed(2);
                const providerAmount = (totalAmount - platformFee).toFixed(2);

                return actions.order.create({
                    purchase_units: [{
                        amount: {
                            currency_code: "USD",
                            value: totalAmount.toFixed(2)
                        }
                    }]
                });
            },

            onApprove: function(data, actions) {
                return actions.order.capture().then(function(details) {
                    const totalAmount = parseFloat(details.purchase_units[0].amount.value);
                    const platformFee = (totalAmount * 0.06).toFixed(2);
                    const providerAmount = (totalAmount - platformFee).toFixed(2);
                    const providerEmail = document.getElementById('account_id').value.trim();

                    // Call server to process platform fee and provider payout
                    fetch('/process-payment_sandbox.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            transaction_id: details.id,
                            total_amount: totalAmount,
                            platform_fee: platformFee,
                            provider_amount: providerAmount,
                            provider_email: providerEmail,
                            status: details.status
                        })
                    })
                    .then(response => response.json())
                    .then(data => alert(data.message))
                    .catch(error => console.error('Error:', error));
                });
            },

            onError: function(err) {
                console.error('PayPal Checkout Error:', err);
                alert('Payment failed. Please try again.');
            }
        }).render('#paypal-button-container');
    </script>

</body>
</html>
