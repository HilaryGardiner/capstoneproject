<?php
session_start();
include 'db_connection.php';

header("Content-Type: application/json");
$data = json_decode(file_get_contents("php://input"), true);

if (!$data) {
    echo json_encode(["success" => false, "message" => "Invalid request"]);
    exit;
}

$transaction_id = $data['transaction_id'];
$total_amount = $data['total_amount'];
$platform_fee = $data['platform_fee'];
$provider_amount = $data['provider_amount'];
$provider_email = $data['provider_email'];
$status = $data['status'];

// PayPal API credentials
$clientId = "AX5LOI7bDCBn5XJVhy4SwZVihemHZJY9OYrDTnJxVyCbd8whkG7yTWXCZU_-2GeAQcGT6MQtkeX_ddPQ";
$secret = "EBjtnaWJbwogtXd-XLJGnx_GcEddpeWZDNG6AQ4xV9rFesEhFNFbguU0LdH1YFR9qOywoD8o3dnKhnZg";

// Get access token
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://api-m.paypal.com/v1/oauth2/token");
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Accept: application/json",
    "Accept-Language: en_US"
]);
curl_setopt($ch, CURLOPT_USERPWD, "$clientId:$secret");
curl_setopt($ch, CURLOPT_POSTFIELDS, "grant_type=client_credentials");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
curl_close($ch);
$auth = json_decode($response, true);
$accessToken = $auth['access_token'] ?? null;

if (!$accessToken) {
    echo json_encode(["success" => false, "message" => "Failed to authenticate PayPal"]);
    exit;
}

// PayPal Payout API URL
$payoutUrl = "https://api-m.paypal.com/v1/payments/payouts";

// Prepare payout request
$payoutData = [
    "sender_batch_header" => [
        "sender_batch_id" => uniqid(),
        "email_subject" => "You've received a payment!"
    ],
    "items" => [
        /*[
            "recipient_type" => "EMAIL",
            "receiver" => "hilary8gardiner@gmail.com",
            "amount" => [
                "currency" => "USD",
                "value" => $platform_fee
            ],
            "note" => "Platform fee deduction",
            "sender_item_id" => uniqid()
        ],*/
        [
            "recipient_type" => "EMAIL",
            "receiver" => $provider_email,
            "amount" => [
                "currency" => "USD",
                "value" => $provider_amount
            ],
            "note" => "Your service payment",
            "sender_item_id" => uniqid()
        ]
    ]
];

// Send payout request
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $payoutUrl);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Content-Type: application/json",
    "Authorization: Bearer $accessToken"
]);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payoutData));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$payoutResponse = curl_exec($ch);
curl_close($ch);
$payoutResult = json_decode($payoutResponse, true);

// Check response
if (isset($payoutResult['batch_header']['payout_batch_id'])) {
    echo json_encode(["success" => true, "message" => "Payment processed successfully."]);
} else {
    echo json_encode(["success" => false, "message" => "Payout failed.", "error" => $payoutResult]);
}
?>
