<?php
session_start();
include 'db_connection.php';


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <script>

        //Create a function to request an access token using client credentials.
const axios = require('axios');
const qs = require('qs');

const clientId = 'ATXuQ0kHZv3mkhOiE1MCWOV-8D7BcVu57c3YCmi24Lt06TZYU8XlFwEB5vLBpA2QWpaTFRnfZq6wAwaR';
const clientSecret = 'EHF1QrjtrerE22AK0WIJxAPg_BD_GFReUQdnwpF5DRGMogXaH4OSiXOq0jX2J56AGj68cvhmnMgCoCM_';

const getAccessToken = async () => {
    try {
        const auth = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');

        const response = await axios.post(
            'https://api-m.sandbox.paypal.com/v1/oauth2/token',
            qs.stringify({ grant_type: 'client_credentials' }),
            {
                headers: {
                    'Authorization': `Basic ${auth}`,
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
            }
        );

        return response.data.access_token;
    } catch (error) {
        console.error('Error getting access token:', error.response ? error.response.data : error.message);
    }
};

// Test: Run getAccessToken()
// getAccessToken().then(token => console.log("Access Token:", token));


const makePayout = async () => {
    const accessToken = await getAccessToken();
    if (!accessToken) return;

    const payoutData = {
        sender_batch_header: {
            sender_batch_id: "2014021801",
            recipient_type: "EMAIL",
            email_subject: "You have money!",
            email_message: "You received a payment. Thanks for using our service!"
        },
        items: [
            {
                amount: { value: "9.87", currency: "USD" },
                sender_item_id: "201403140001",
                recipient_wallet: "PAYPAL",
                receiver: "sb-ek8jf36750766@business.example.com"
            },
            {
                amount: { value: "112.34", currency: "USD" },
                sender_item_id: "201403140002",
                recipient_wallet: "PAYPAL",
                receiver: "sb-qxa7q36907543@business.example.com"
            }
        ]
    };

    try {
        const response = await axios.post(
            'https://api-m.sandbox.paypal.com/v1/payments/payouts',
            payoutData,
            {
                headers: {
                    'Authorization': `Bearer ${accessToken}`,
                    'Content-Type': 'application/json',
                },
            }
        );

        console.log('Payout Response:', response.data);
    } catch (error) {
        console.error('Error making payout:', error.response ? error.response.data : error.message);
    }
};

// Run the function
makePayout();

    </script>
    
</body>
</html>