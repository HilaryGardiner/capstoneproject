<?php

function checkPayoutStatus($batchId, $accessToken) {
    $url = "https://api-m.sandbox.paypal.com/v1/payments/payouts/$batchId";

    $headers = [
        "Content-Type: application/json",
        "Authorization: Bearer $accessToken"
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);
    curl_close($ch);

    return json_decode($response, true);
}

// Usage:
$batchId = "Payouts_2018_100007"; // Replace with actual batch ID
$accessToken = getPayPalAccessToken();
$response = checkPayoutStatus($batchId, $accessToken);
echo "<pre>";
print_r($response);
echo "</pre>";
?>