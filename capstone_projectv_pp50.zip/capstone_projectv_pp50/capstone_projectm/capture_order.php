<?php
session_start();
include 'db_connection.php';

header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$orderID = $data['orderID'] ?? '';

if (!$orderID) {
    die(json_encode(["error" => "Invalid order ID."]));
}

$clientId = "AaBLxhzRIQR8U9guxYiDu3qF0ldRs-asz9wcAaOpEonHqOjMA4K4KOLD2FtJxH7ANK3aKzWfoH3ricSN";
$clientSecret = "EF4d78BsruUpi_xnmi7gvlGUJIUHL_7yxfUkiyQpK5a_gHFoedol56PKRLK5NwO4VOvOYPXaduGFA81F";

$accessToken = getPayPalAccessToken($clientId, $clientSecret);
if (!$accessToken) {
    die(json_encode(["error" => "Failed to get PayPal access token."]));
}

$url = "https://api-m.sandbox.paypal.com/v2/checkout/orders/$orderID/capture";
$headers = [
    "Content-Type: application/json",
    "Authorization: Bearer $accessToken"
];

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);

$response = curl_exec($ch);
curl_close($ch);

echo $response;

function getPayPalAccessToken($clientId, $clientSecret) {
    $url = "https://api-m.sandbox.paypal.com/v1/oauth2/token";
    $headers = ["Accept: application/json", "Accept-Language: en_US"];
    $postFields = "grant_type=client_credentials";

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_USERPWD, "$clientId:$clientSecret");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

    $response = curl_exec($ch);
    curl_close($ch);
    $jsonResponse = json_decode($response, true);

    return $jsonResponse['access_token'] ?? null;
}
?>
