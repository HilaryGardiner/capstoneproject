<?php

session_start();
include 'db_connection.php';

//how to get your access token using cURL

/* curl -v -X POST "https://api-m.sandbox.paypal.com/v1/oauth2/token"\
-u "CLIENT_ID:CLIENT_SECRET"\
-H "Content-Type: application/x-www-form-urlencoded"\
-d "grant_type=client_credentials"
     

*/

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <script>

const axios = require('axios');
const qs = require('qs');

const clientId = 'ATXuQ0kHZv3mkhOiE1MCWOV-8D7BcVu57c3YCmi24Lt06TZYU8XlFwEB5vLBpA2QWpaTFRnfZq6wAwaR';
const clientSecret = 'EHF1QrjtrerE22AK0WIJxAPg_BD_GFReUQdnwpF5DRGMogXaH4OSiXOq0jX2J56AGj68cvhmnMgCoCM_';

const auth = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');

const getToken = async () => {
    try {
        const response = await axios.post(
            'https://api-m.sandbox.paypal.com/v1/oauth2/token',
            qs.stringify({ grant_type: 'client_credentials' }),
            {
                headers: {
                    'Authorization': `Basic ${auth}`,
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
            }
        );
        console.log('Access Token:', response.data.access_token);
    } catch (error) {
        console.error('Error:', error.response ? error.response.data : error.message);
    }
};

getToken();

    </script>
</body>
</html>