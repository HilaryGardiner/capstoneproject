<?php
// Start session
session_start();

// Include database connection
include 'db_connection.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Check if the user has completed the background check
$user_id = $_SESSION['user_id'];
$sql_check = "SELECT background_check_completed FROM users WHERE id = ?";
$stmt = $conn->prepare($sql_check);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user || !$user['background_check_completed']) {
    // Check if admin is logged in
    $is_admin = isset($_SESSION['is_admin']) && $_SESSION['is_admin'] === true;

    echo "
    <!doctype html>
    <html lang='en'>
    <head>
        <title>Background Check Required</title>
        <meta charset='utf-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1'>
        <link rel='stylesheet' href='styles/main.css'>
    </head>
    <body>
        <div style='text-align:center; margin-top:50px;'>
            <h2>Access Restricted</h2>
            <p>You need to complete a background check to access this page.</p>
            <a href='https://www.example-background-check.com' target='_blank' style='color:blue; text-decoration:underline;'>Click here to complete your background check</a>
            <p>Once you've completed the background check, contact the administrator to unlock access.</p>";

    if ($is_admin) {
        echo "<p><a href='unlock_access.php'>Go to Unlock Interface</a></p>";
    }

    echo "
        </div>
    </body>
    </html>
    ";
    exit();
}

?>
<!doctype html>
<html lang="en">
<head>
    <title>iHire</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="images/logo3.jpg">
    <link rel="stylesheet" href="styles/main.css">
    <link rel="stylesheet" href="styles/slicknav.css">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="js/jquery.slicknav.min.js"></script>
    <script>
    $(document).ready(function() {
        $('#nav_menu').slicknav({ prependTo: "#mobile_menu" });
    });
    </script>

    <style>
        .custom-margin {
            margin-left: 1.3em;
        }

        /*Styling for div element */
        .job-details {
	    margin: left;
	    padding: 5px;
	    border: 1px solid #ccc;
	    width: 50%;
        height: 20%;
	    /*max-width: 25%;*/
	    /*box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);*/
	    background-color: #f9f9f9;
        }

    </style>
</head>
<body>
    <header>
        <a href="index.php"><img src="images/logo3.jpg" alt="iHire Logo"></a>
        <h3 style="font-size: 1.25em; font-style: italic; color: #f2972e;">SwiftConnections: Bridging Needs, Building Opportunities</h3>
        <h4 style="color: #f2972e;">Welcome My Friend!</h4>
    </header>
    <nav id="mobile_menu"></nav>
    <nav id="nav_menu">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="postjob.php">Post Job</a></li>
            <li><a href="#">Job Details</a>
                <ul>
                    <li><a href="job_details.php">View Posted Jobs</a></li>
                    <li><a href="messages.php">View Your Messages</a></li>
                    <li><a href="service_checkin.php">Check in here!</a> </li>
                </ul>
                
            </li>
            <li><a href="userprofile.php">User Profile</a></li>
            <li class="lastitem"><a href="paymentcode.php">Payments</a></li>
        </ul>
    </nav>
    <main>
        <section>
            <h1>About Us</h1>
            <nav>
                <ul>
                    <li><a href="speakers/contact_info.html">Contact</a></li>
                </ul>
                <h1>Note</h1>
                <ul>
                    <li><p style="color: #f2972e;">
            
                    <b>Note: You must use the platform payment processing for all monetary transactions. 
                    Failure to comply will lead to suspension and later termination of service.
                    </b>
                    </p></li>
                </ul>
            </nav>

            

        </section>
        <aside>
            <h2>Mission Statement</h2>
            <p>We strive to create a web/mobile app bridging individuals with services, enhancing accessibility post-pandemic. Motivated by pandemic challenges, we aim to offer seamless assistance, empowering users while providing rich development experiences.</p>
        </aside>
        
        <!--<div class="job-details">
        <p style="color: #f2972e;">
            
            <b>Note: You must use the platform payment processing for all monetary transactions. 
                Failure to comply will lead to suspension and later termination of service.
            </b>
        </p>
        </div>-->

        
        <br><div><h3>Notifications</h3></div>
        <?php
        // Fetch unread notifications for the logged-in user
        $sql_notifications = "SELECT id, message FROM notifications WHERE user_id = ? AND is_read = 0";
        $stmt = $conn->prepare($sql_notifications);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<div class='notification'>{$row['message']}</div>";
                $notification_id = $row['id'];
                $sql_mark_read = "UPDATE notifications SET is_read = 1 WHERE id = ?";
                $stmt_mark_read = $conn->prepare($sql_mark_read);
                $stmt_mark_read->bind_param("i", $notification_id);
                $stmt_mark_read->execute();
            }
        } else {
            //echo "<p>No new notifications.</p>";
            echo '<p class="custom-margin">No new notifications.</p>';
        }

        $conn->close();
        ?>
    </main>
    <footer>
        <p>You are not alone!</p>
    </footer>
</body>
</html>

