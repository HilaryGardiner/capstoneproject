<?php
session_start();
include 'db_connection.php';

function getPayPalAccessToken() {
    $clientId = 'ATXuQ0kHZv3mkhOiE1MCWOV-8D7BcVu57c3YCmi24Lt06TZYU8XlFwEB5vLBpA2QWpaTFRnfZq6wAwaR'; // Replace with your PayPal Client ID
    $secret = 'EHF1QrjtrerE22AK0WIJxAPg_BD_GFReUQdnwpF5DRGMogXaH4OSiXOq0jX2J56AGj68cvhmnMgCoCM_'; // Replace with your PayPal Secret

    $url = "https://api-m.sandbox.paypal.com/v1/oauth2/token";
    
    $headers = [
        "Accept: application/json",
        "Accept-Language: en_US",
        "Content-Type: application/x-www-form-urlencoded"
    ];

    $data = "grant_type=client_credentials";

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_USERPWD, "$clientId:$secret");
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);

    $response = curl_exec($ch);
    curl_close($ch);

    $json = json_decode($response, true);

    return $json['access_token'] ?? null;
}

// Usage:
$accessToken = getPayPalAccessToken();
echo "Access Token: " . $accessToken;
