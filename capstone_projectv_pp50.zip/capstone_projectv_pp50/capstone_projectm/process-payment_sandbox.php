<?php
session_start();
include 'db_connection.php';

header("Content-Type: application/json");
$data = json_decode(file_get_contents("php://input"), true);

if (!$data) {
    echo json_encode(["success" => false, "message" => "Invalid request"]);
    exit;
}

$transaction_id = $data['transaction_id'];
$total_amount = $data['total_amount'];
$platform_fee = $data['platform_fee'];
$provider_amount = $data['provider_amount'];
$provider_email = $data['provider_email'];
$status = $data['status'];

// PayPal Sandbox API credentials
$clientId = "AaBLxhzRIQR8U9guxYiDu3qF0ldRs-asz9wcAaOpEonHqOjMA4K4KOLD2FtJxH7ANK3aKzWfoH3ricSN";
$secret = "EF4d78BsruUpi_xnmi7gvlGUJIUHL_7yxfUkiyQpK5a_gHFoedol56PKRLK5NwO4VOvOYPXaduGFA81F";

// Get access token
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://api-m.sandbox.paypal.com/v1/oauth2/token");
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Accept: application/json",
    "Accept-Language: en_US"
]);
curl_setopt($ch, CURLOPT_USERPWD, "$clientId:$secret");
curl_setopt($ch, CURLOPT_POSTFIELDS, "grant_type=client_credentials");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($ch);
curl_close($ch);
$auth = json_decode($response, true);
$accessToken = $auth['access_token'] ?? null;

if (!$accessToken) {
    echo json_encode(["success" => false, "message" => "Failed to authenticate PayPal"]);
    exit;
}

// PayPal Payout API URL (Sandbox)
$payoutUrl = "https://api-m.sandbox.paypal.com/v1/payments/payouts";

// Prepare payout request
$payoutData = [
    "sender_batch_header" => [
        "sender_batch_id" => uniqid(),
        "email_subject" => "You've received a sandbox payment!"
    ],
    "items" => [
        [
            "recipient_type" => "EMAIL",
            "receiver" => "sb-qxa7q36907543@business.example.com", // Replace with your sandbox business account email
            "amount" => [
                "currency" => "USD",
                "value" => $platform_fee
            ],
            "note" => "Platform fee deduction",
            "sender_item_id" => uniqid()
        ],
        [
            "recipient_type" => "EMAIL",
            "receiver" => $provider_email,
            "amount" => [
                "currency" => "USD",
                "value" => $provider_amount
            ],
            "note" => "Your service payment",
            "sender_item_id" => uniqid()
        ]
    ]
];

// Send payout request
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $payoutUrl);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Content-Type: application/json",
    "Authorization: Bearer $accessToken"
]);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payoutData));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$payoutResponse = curl_exec($ch);
curl_close($ch);
$payoutResult = json_decode($payoutResponse, true);

// Check response
if (isset($payoutResult['batch_header']['payout_batch_id'])) {
    echo json_encode(["success" => true, "message" => "Sandbox payment processed successfully."]);
} else {
    echo json_encode(["success" => false, "message" => "Payout failed.", "error" => $payoutResult]);
}
?>
