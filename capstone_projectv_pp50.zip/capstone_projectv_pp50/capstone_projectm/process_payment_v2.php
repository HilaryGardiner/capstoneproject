<?php
session_start();
include 'db_connection.php';
require __DIR__ . '/vendor/autoload.php'; // Stripe SDK

\Stripe\Stripe::setApiKey('sk_live_262626262jfjfjfj728282882'); // Replace with your secret key

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=$charset", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);

    $stmt = $pdo->prepare("SELECT id, email, stripe_account_id FROM users WHERE id != ?");
    $stmt->execute([$user_id]);
    $users = $stmt->fetchAll();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['receiver_id'], $_POST['amount'], $_POST['stripeToken'])) {
            $receiver_id = $_POST['receiver_id'];
            $amount = (float)$_POST['amount'];
            $token = $_POST['stripeToken'];

            $stmt = $pdo->prepare("SELECT stripe_account_id FROM users WHERE id = ?");
            $stmt->execute([$receiver_id]);
            $receiver = $stmt->fetch();

            if (!$receiver || !$receiver['stripe_account_id']) {
                throw new Exception("Receiver does not have a connected Stripe account.");
            }

            $receiverStripeAccount = $receiver['stripe_account_id'];

            $charge = \Stripe\Charge::create([
                'amount' => $amount * 100, // Convert to cents
                'currency' => 'usd',
                'description' => "Payment from user $user_id to user $receiver_id",
                'source' => $token,
                'transfer_data' => [
                    'destination' => $receiverStripeAccount,
                ],
            ]);

            $stmt = $pdo->prepare("INSERT INTO transactions (transaction_id, payer_id, receiver_id, amount, status, created_at) 
                                   VALUES (?, ?, ?, ?, ?, NOW())");
            $stmt->execute([$charge->id, $user_id, $receiver_id, $amount, $charge->status]);

            echo "Payment of $$amount was successful. Transaction ID: " . $charge->id;
        } else {
            echo "Error: Required payment information is missing.";
        }
    }
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    die("Database error occurred. Please try again.");
} catch (Exception $e) {
    error_log("Stripe error: " . $e->getMessage());
    die("Payment error occurred: " . $e->getMessage());
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Process Payment</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <script src="https://js.stripe.com/v3/"></script>

    <link rel="shortcut icon" href="images/logo3.jpg">
    <link rel="stylesheet" href="styles/main.css">
    <link rel="stylesheet" href="styles/slicknav.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="js/jquery.slicknav.min.js"></script>
    <script>
        $(document).ready(function(){
            $('#nav_menu').slicknav({prependTo:"#mobile_menu"});
        });
    </script>
</head>
<body>

<header>
    <a href="index.php"><img src="images/logo3.jpg" alt="Logo"></a>
    <h3 style="color: #f2972e;">SwiftConnections: Bridging Needs, Building Opportunities</h3>
    <h4>Welcome My Friend!</h4>
</header>

<nav id="mobile_menu"></nav>
<nav id="nav_menu">
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="postjob.php">Post Job</a></li>
        <li><a href="#">Job Details</a>
            <ul>
                <li><a href="job_details.php">View Posted Jobs</a></li>
                <li><a href="messages.php">View Your Messages</a></li>
            </ul>
        </li>
        <li><a href="userprofile.php">User Profile</a></li>
        <li class="lastitem"><a href="process_payment.php">Payments</a></li>
    </ul>
</nav>



</body>
</html>