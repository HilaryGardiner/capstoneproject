<?php
// Start session
session_start();

// Include database connection
include 'db_connection.php';

try {
    // Check if there are any admin accounts in the database
    $sql_check_admins = "SELECT COUNT(*) AS admin_count FROM admins";
    $stmt = $conn->prepare($sql_check_admins);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    $admin_count = $row['admin_count'];

    // If there are existing admins and the user is not logged in as admin, redirect to login
    if ($admin_count > 0 && (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true)) {
        header("Location: login.php");
        exit();
    }
} catch (Exception $e) {
    die("Error checking admin accounts: " . $e->getMessage());
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Validate inputs
    if (empty($username) || empty($password) || empty($confirm_password)) {
        $error = "All fields are required.";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } else {
        try {
            // Hash the password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Insert admin details into the database
            $sql_insert = "INSERT INTO admins (username, password) VALUES (?, ?)";
            $stmt = $conn->prepare($sql_insert);
            $stmt->bind_param("ss", $username, $hashed_password);

            if ($stmt->execute()) {
                $success = "Admin account created successfully.";
                // Redirect to login if this was the first admin account creation
                if ($admin_count === 0) {
                    header("Location: login.php");
                    exit();
                }
            } else {
                $error = "Error creating admin account. Please try again.";
            }
        } catch (Exception $e) {
            $error = "Database error: " . $e->getMessage();
        }
    }
}
?>

<!doctype html>
<html lang="en">
<head>
    <title>Create Admin Account</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="styles/admin.css">
</head>
<body>
    <div class="container">
        <h1>Create Admin Account</h1>
        <?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
        <?php if (isset($success)) echo "<p style='color:green;'>$success</p>"; ?>
        <form method="POST">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            <label for="confirm_password">Confirm Password:</label>
            <input type="password" id="confirm_password" name="confirm_password" required>
            <button type="submit">Create Admin</button>
        </form>
    </div>
</body>
</html>
