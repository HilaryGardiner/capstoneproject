<?php
session_start();
include 'db_connection.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$job_id = '';
$checkin_data = null;
$message = '';

// Process job ID submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['job_id'])) {
    $job_id = intval($_POST['job_id']);
    
    $sql_checkin = "SELECT id, job_description, job_duration, pay_rate, city, state, posted_at, user_id 
                    FROM postjobtable WHERE id = ?";
    
    $stmt = $conn->prepare($sql_checkin);
    if ($stmt) {
        $stmt->bind_param("i", $job_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $checkin_data = $result->fetch_assoc();
        $stmt->close();
        
        if (!$checkin_data) {
            $message = "Job not found.";
        }
    } else {
        die("Error preparing statement: " . $conn->error);
    }
}

// Process customer acknowledgment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acknowledge']) && isset($_POST['job_id'])) {
    $job_id = intval($_POST['job_id']);

// Fetch user's name from the database
$sql_user = "SELECT fname, lname FROM users WHERE id = ?";

$stmt = $conn->prepare($sql_user);
if ($stmt) {
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user_data = $result->fetch_assoc();
    $stmt->close();

    if ($user_data) {
        $user_name = $user_data['fname'] . ' ' . $user_data['lname']; // Concatenate first and last name
    } else {
        die("Error: User not found.");
    }
} else {
    die("Error preparing statement: " . $conn->error);
}



  // Insert acknowledgment into the checkins table
$sql_insert_checkin = "INSERT INTO checkins (job_id, customer_id, customer_name, acknowledged_at) VALUES (?, ?, ?, NOW())";
$stmt = $conn->prepare($sql_insert_checkin);

if ($stmt) {
    $stmt->bind_param("iis", $job_id, $user_id, $user_name);
    $stmt->execute();
    $stmt->close();
    $message = "Check-in acknowledged successfully.";
    echo "<script>alert('Check-in successful');</script>";
} else {
    die("Error preparing statement: " . $conn->error);
}

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
    <title>Post Job</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="images/logo3.jpg">
    <link rel="stylesheet" href="styles/main.css">
    <link rel="stylesheet" href="styles/slicknav.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="js/jquery.slicknav.min.js"></script>

	
    <script>
        $(document).ready(function(){
            $('#nav_menu').slicknav({prependTo:"#mobile_menu"});
        });
    </script>


<style>
    h1 {
        text-align: center;
        font-size: 2.5vw; /* Adjust font size based on viewport width */
        margin: 10px auto; /* Add some spacing */
        padding: 10px;
    }

    /* Ensure a minimum and maximum font size for better readability */
    @media (max-width: 480px) {
        h1 {
            font-size: 18px; /* Set a readable font size on small screens */
        }
    }

    @media (min-width: 1200px) {
        h1 {
            font-size: 32px; /* Set a max font size for large screens */
        }
    }


    .job-details {
            margin: auto;
            padding: 20px;
            border: 1px solid #ccc;
            width: 80%;
            max-width: 600px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            background-color: #f9f9f9;
        }
</style>


   
</head>

<body>
	<header>
        <a href="index.php"><img src="images/logo3.jpg" alt="iHire Logo" ></a>
        <h3 style="color: #f2972e;">SwiftConnections: Bridging Needs, Building Opportunities</h3>
        <h4>Welcome My Friend!</h4>
        
    </header>
    <nav id="mobile_menu"></nav>
    <nav id="nav_menu">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="postjob.php">Post Job</a>
                
            </li>
            <li><a href="#">Job Details</a>
                <ul>
                    <li><a href="job_details.php">View Posted Jobs</a> </li>
                    <li><a href="messages.php">View Your Messages</a></li> 
                    <li><a href="service_checkin.php">Check in here!</a> </li>
                </ul>
            </li>
            <li><a href="userprofile.php">User Profile</a>
                
            </li>
            <li class="lastitem"><a href="paymentcode.php">Payments</a>
                
            </li>
            
            
            
        </ul>
    </nav>
    <h1>Service Check-In</h1>
        
    <form method="POST">
        <label for="job_id">Enter Job ID:</label>
        <input type="number" id="job_id" name="job_id" required>
        <button type="submit">Check In</button>
    </form>

    
    
    <?php if (!empty($message)): ?>
        <div class="job-details">
        <p><strong><?php echo htmlspecialchars($message); ?></strong></p>
        </div>
    <?php endif; ?>
    
    <?php if ($checkin_data): ?>
        <div class="job-details">
        <p><strong>Job Details</strong></p>
        <p><strong>Job Description:</strong> <?php echo htmlspecialchars($checkin_data['job_description']); ?></p>
        <p><strong>Job Duration:</strong> <?php echo $checkin_data['job_duration']; ?> hours</p>
        <p><strong>Pay Rate:</strong> $<?php echo $checkin_data['pay_rate']; ?>/hour</p>
        <p><strong>Location:</strong> <?php echo htmlspecialchars($checkin_data['city']) . ", " . htmlspecialchars($checkin_data['state']); ?></p>
        <p><strong>Posted At:</strong> <?php echo $checkin_data['posted_at']; ?></p>
        </div><br>
        <form method="POST">
            <input type="hidden" name="job_id" value="<?php echo $checkin_data['id']; ?>">
            <button type="submit" name="acknowledge">Acknowledge Check-In</button>
        </form>
    <?php endif; ?>

    <div class="job-details">
        <p style="color: #f2972e;">
            
            <b>Note: The check in is intended for the customer
            and the service provider to acknowledge that they both met each other.
            Each individual has to check in separately on his/her phone or device.
            Failure to check in will lead to suspension and later 
            termination of service.
            </b>
        </p>
    </div>
</body>
</html>
