<?php
session_start();
include 'db_connection.php';

try {
    // Set up the DSN (Data Source Name)
    $dsn = "mysql:host=$host;dbname=$dbname;charset=$charset";

    // Create a new PDO instance
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,  // Set PDO error mode to exception
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, // Fetch associative arrays by default
        PDO::ATTR_EMULATE_PREPARES => false,  // Disable emulation mode for prepared statements
    ]);

    // SQL statement to delete the checkins table
    $dropTableSql = "DROP TABLE IF EXISTS checkins";

    // Execute the SQL statement
    $pdo->exec($dropTableSql);
    echo "Table 'checkins' deleted successfully.";

} catch (PDOException $e) {
    // Handle any errors that occur during the deletion
    echo "Error: " . $e->getMessage();
}
?>
