<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $recipientEmail = filter_var($_POST['recipient_email'], FILTER_SANITIZE_EMAIL);
    $amount = filter_var($_POST['amount'], FILTER_VALIDATE_FLOAT);

    if (!$recipientEmail || !$amount || $amount <= 0) {
        die("Invalid input. Please enter a valid email and amount.");
    }

    // Hardcoded email to receive 20%
    $hardcodedEmail = "sb-kxw9u36869299@personal.example.com";

    // Split the amount: 80% to the user-entered email, 20% to the hardcoded email
    $amountUser = round($amount * 0.8, 2);
    $amountAdmin = round($amount * 0.2, 2);

    function getPayPalAccessToken() {
        $clientId = "AaBLxhzRIQR8U9guxYiDu3qF0ldRs-asz9wcAaOpEonHqOjMA4K4KOLD2FtJxH7ANK3aKzWfoH3ricSN";
    	$clientSecret = "EF4d78BsruUpi_xnmi7gvlGUJIUHL_7yxfUkiyQpK5a_gHFoedol56PKRLK5NwO4VOvOYPXaduGFA81F";

        $url = "https://api-m.sandbox.paypal.com/v1/oauth2/token";
        $headers = [
            "Accept: application/json",
            "Accept-Language: en_US"
        ];
        $postFields = "grant_type=client_credentials";

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_USERPWD, "$clientId:$clientSecret");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

        $response = curl_exec($ch);
        curl_close($ch);
        $jsonResponse = json_decode($response, true);

        return $jsonResponse['access_token'] ?? null;
    }

    function createPayout($accessToken, $recipientEmail, $amountUser, $hardcodedEmail, $amountAdmin) {
        $url = "https://api-m.sandbox.paypal.com/v1/payments/payouts";

        $data = [
            "sender_batch_header" => [
                "sender_batch_id" => uniqid("Payouts_"), 
                "email_subject" => "You have received a payout!",
                "email_message" => "Your payment has been processed."
            ],
            "items" => [
                [
                    "recipient_type" => "EMAIL",
                    "amount" => [
                        "value" => strval($amountUser),
                        "currency" => "USD"
                    ],
                    "note" => "Your 80% payout!",
                    "sender_item_id" => uniqid("User_"),
                    "receiver" => $recipientEmail
                ],
                [
                    "recipient_type" => "EMAIL",
                    "amount" => [
                        "value" => strval($amountAdmin),
                        "currency" => "USD"
                    ],
                    "note" => "Business fee (20%)",
                    "sender_item_id" => uniqid("Admin_"),
                    "receiver" => $hardcodedEmail
                ]
            ]
        ];

        $headers = [
            "Content-Type: application/json",
            "Authorization: Bearer $accessToken"
        ];

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

        $response = curl_exec($ch);
        curl_close($ch);
        return json_decode($response, true);
    }

    $accessToken = getPayPalAccessToken();
    if (!$accessToken) {
        die("Error: Failed to retrieve PayPal access token.");
    }

    $response = createPayout($accessToken, $recipientEmail, $amountUser, $hardcodedEmail, $amountAdmin);

    echo "<h3>Payout Response:</h3>";
    echo "<pre>" . json_encode($response, JSON_PRETTY_PRINT) . "</pre>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>PayPal Payout</title>
</head>
<body>
    <h2>Enter Payout Details</h2>
    <form method="post">
        <label for="recipient_email">Recipient Email:</label>
        <input type="email" name="recipient_email" required><br><br>

        <label for="amount">Amount (USD):</label>
        <input type="number" name="amount" step="0.01" required><br><br>

        <button type="submit">Pay</button>
    </form>
</body>
</html>
