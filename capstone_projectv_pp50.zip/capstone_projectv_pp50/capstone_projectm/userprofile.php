<?php
session_start();
include 'db_connection.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirect to login page if not logged in
    exit();
}

$user_id = $_SESSION['user_id'];

try {
    // Database connection
    $dsn = "mysql:host=$host;dbname=$dbname;charset=$charset";
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);

    // Retrieve user information
    $stmt = $pdo->prepare("SELECT u.fname, u.lname, u.email, u.phone, u.address, u.profile_picture
                       FROM users u 
                       WHERE u.id = ?");

    $stmt->execute([$user_id]);
    $user = $stmt->fetch();

    if ($user) {
        $profilePicture = $user['profile_picture'] ?: 'images/default_profile.png'; // Default picture if none
        $fname = $user['fname'];
        $lname = $user['lname'];
        $email = $user['email'];
        $phone = $user['phone'];
        $address = $user['address'];
    } else {
        echo "User not found.";
        exit();
    }

} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
    <title>User Profile</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="styles/main.css">
    <link rel="stylesheet" href="styles/slicknav.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="js/jquery.slicknav.min.js"></script>
    
    <style>
        .profile-picture img {
            width: 30%;
            height: 20%;
            object-fit: cover;
            border-radius: 50%;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 0.75em;
            margin-left: 0.75em;
        }
        .form-group {
            margin-bottom: 15px;
        }
    </style>

    <script>
        $(document).ready(function(){
            $('#nav_menu').slicknav({prependTo:"#mobile_menu"});
        });
    </script>
</head>

<body>
    <header>
        <a href="index.php"><img src="images/logo3.jpg" alt="Logo"></a>
        <h3>SwiftConnections: Bridging Needs, Building Opportunities</h3>
        <h4>Welcome, <?php echo htmlspecialchars($fname); ?>!</h4>
    </header>
    <nav id="mobile_menu"></nav>
    <nav id="nav_menu">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="postjob.php">Post Job</a></li>
            <li><a href="#">Job Details</a>
                <ul>
                    <li><a href="job_details.php">View Posted Jobs</a></li>
                    <li><a href="messages.php">View Your Messages</a></li>
                    <li><a href="service_checkin.php">Check in here!</a> </li>
                </ul>
            </li>
            <li><a href="userprofile.php">User Profile</a></li>
            <li class="lastitem"><a href="paymentcode.php">Payments</a></li>
        </ul>
    </nav>
    <div class="container">
        <h1>Edit Profile</h1>

        <div class="profile-picture">
            <img src="<?php echo htmlspecialchars($profilePicture); ?>" alt="Profile Picture">
        </div>

        <form id="profile-form" action="update_profile.php" method="POST" enctype="multipart/form-data">
            <div class="profile-section">
                <h2>Profile Information</h2>
                <div class="form-group">
                    <label for="profile_picture">Profile Picture:</label>
                    <input type="file" name="profile_picture" accept="image/*">
                </div>
                <div class="form-group">
                    <label for="fname">First Name:</label>
                    <input type="text" id="fname" name="fname" value="<?php echo htmlspecialchars($fname); ?>" required>
                </div>
                <div class="form-group">
                    <label for="lname">Last Name:</label>
                    <input type="text" id="lname" name="lname" value="<?php echo htmlspecialchars($lname); ?>" required>
                </div>
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
                </div>
                <div class="form-group">
                    <label for="phone">Phone:</label>
                    <input type="text" id="phone" name="phone" value="<?php echo htmlspecialchars($phone); ?>">
                </div>
                <div class="form-group">
                    <label for="address">Address:</label>
                    <textarea id="address" name="address"><?php echo htmlspecialchars($address); ?></textarea>
                </div>
                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" placeholder="Enter new password if changing">
                </div>
            </div>
            <button type="submit">Save Changes</button>
        </form>
    </div>
</body>
</html>
