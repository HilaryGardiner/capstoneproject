


<!DOCTYPE html>
<html lang="en">
<head>
	<title>Job Details</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial scale=1">
	<link rel="shortcut icon" href="images/logo3.jpg">
	<link rel="stylesheet" href="styles/main.css">
	<link rel="stylesheet" href="styles/slicknav.css">
    <link rel="stylesheet" href="table_form.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="js/jquery.slicknav.min.js"></script>
    <script>
        $(document).ready(function(){
            $('#nav_menu').slicknav({prependTo:"#mobile_menu"});
        });
    </script>
</head>

<body style="margin: 15px auto;">

    <header>
        <a href="index.php"><img src="images/logo3.jpg" alt="iHire Logo" ></a>
        <h3>SwiftConnections: Bridging Needs, Building Opportunities</h3>
        <h4>Welcome My Friend!</h4>
        
    </header>
    <nav id="mobile_menu"></nav>
    <nav id="nav_menu">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="postjob.php">Post Job</a>
                
            </li>
            <li><a href="#">Job Details</a>
                <ul>
                    <li><a href="job_details.php">View Posted Jobs</a> </li>
                    <li><a href="messages.php">View Your Messages</a>
                    </li>
                </ul>
            </li>
            <li><a href="userprofile.php">User Profile</a>
                
            </li>
            <li class="lastitem"><a href="process_payment.php">Payments</a>
                
            </li>
            
            
            
        </ul>
    </nav>
		
   
    
    <?php
// Start the session to use session variables.
session_start();

// Include the database connection file.
include 'db_connection.php';

// Function to sanitize user input by trimming whitespace and escaping special characters.
function sanitize_input($data) {
    return htmlspecialchars(trim($data));
}

// Check if the user is logged in. If not, terminate the script with a message.
if (!isset($_SESSION['user_id'])) {
    die("<div>You must be logged in to view job details.</div></body></html>");
}

// Get the user ID from the session.
$user_id = $_SESSION['user_id'];

// Retrieve search filters (city, state, keyword) from the POST request, if provided.
$city = isset($_POST['city']) ? sanitize_input($_POST['city']) : '';
$state = isset($_POST['state']) ? sanitize_input($_POST['state']) : '';
$keyword = isset($_POST['keyword']) ? sanitize_input($_POST['keyword']) : '';

// Check if the job posting table exists in the database.
$sql_check_table = "SELECT 1 FROM postjobtable LIMIT 1";
$result = $conn->query($sql_check_table);

// If the table exists, proceed to retrieve job postings.
if ($result) {
    // Base SQL query to retrieve all job postings.
    $sql_retrieve_data = "SELECT * FROM postjobtable";

    // Initialize arrays to hold query conditions and parameters.
    $conditions = [];
    $params = [];
    $types = '';

    // Add a filter for city if provided.
    if ($city !== '') {
        $conditions[] = "city = ?";
        $params[] = $city;
        $types .= 's'; // Add a type specifier for a string.
    }

    // Add a filter for state if provided.
    if ($state !== '') {
        $conditions[] = "state = ?";
        $params[] = $state;
        $types .= 's';
    }

    // Add a filter for keyword search in the job description if provided.
    if ($keyword !== '') {
        $conditions[] = "job_description LIKE ?";
        $params[] = "%" . $keyword . "%"; // Use wildcard search.
        $types .= 's';
    }

    // Append conditions to the SQL query if any filters are set.
    if (count($conditions) > 0) {
        $sql_retrieve_data .= " WHERE " . implode(" AND ", $conditions);
    }

    // Add ORDER BY clause to sort by the most recent jobs.
    $sql_retrieve_data .= " ORDER BY posted_at DESC";

    // Prepare the SQL statement.
    $stmt = $conn->prepare($sql_retrieve_data);

    // Bind parameters to the SQL statement if there are any.
    if (count($params) > 0) {
        $stmt->bind_param($types, ...$params);
    }

    // Execute the prepared statement.
    $stmt->execute();

    // Retrieve the result set from the query.
    $result = $stmt->get_result();

    // Begin generating the HTML page content.
    echo "<html><body>";

    // Render a search form with fields for city, state, and keyword.
    echo "<form method='post' action='job_details.php'>
            <label for='city'>City:</label>
            <input type='text' id='city' name='city' value='$city'><br>
            <label for='state'>State:</label>
            <input type='text' id='state' name='state' value='$state' placeholder='Ex., Arizona'><br>
            <label for='keyword'>Keyword (Optional):</label>
            <input type='text' id='keyword' name='keyword' value='$keyword' placeholder='Ex., clean, or clean my house'><br>
            <button type='submit'>Search</button>
          </form>";

    // Render a table to display job details.
    echo "<table class='job-table' border='1'>";
    echo "<tr><th>Job ID</th><th>Description</th><th>Duration</th><th>Pay Rate</th><th>Name</th><th>City</th><th>State</th><th>Posted At</th><th>Messages</th></tr>";

    // Loop through the result set and display each job posting in a table row.
    while ($row = $result->fetch_assoc()) {
        $job_id = $row['id'];
        $description = $row['job_description'];
        $duration = $row['job_duration'];
        $rate = $row['pay_rate'];
        $first_name = $row['first_name'];
        $last_name = $row['last_name'];
        $city = $row['city'];
        $state = $row['state'];
        $posted_at = $row['posted_at'];
        $poster_id = $row['user_id'];

        echo "<tr><td>$job_id</td><td>$description</td><td>$duration</td><td>$rate</td><td>$first_name $last_name</td><td>$city</td><td>$state</td><td>$posted_at</td><td>";

        // Render a form for sending a message to the job poster.
        echo "<form method='post' action='messages.php?job_id=$job_id&receiver_id=$poster_id'>
              <textarea name='message' rows='2' cols='30' placeholder='Type your message'></textarea><br>
              <input type='submit' value='Send'>
              </form>";

        echo "</td></tr>";
    }

    // Close the table and HTML body.
    echo "</table></body></html>";
} else {
    // If the table does not exist, display an error message.
    echo "Error: Table 'postjobtable' does not exist.";
}

// Close the database connection.
$conn->close();
?>



    <br><br>     

        
        <button id="apply-button">Apply</button>
    

    <script src="script.js"></script>
    <footer>
        <p>You are not alone!</p>
    </footer>

</body>
</html>
