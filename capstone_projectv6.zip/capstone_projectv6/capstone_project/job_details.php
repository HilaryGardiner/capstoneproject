


<!DOCTYPE html>
<html lang="en">
<head>
	<title>Job Details</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial scale=1">
	<link rel="shortcut icon" href="images/logo3.jpg">
	<link rel="stylesheet" href="styles/main.css">
	<link rel="stylesheet" href="styles/slicknav.css">
    <link rel="stylesheet" href="table_form.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="js/jquery.slicknav.min.js"></script>
    <script>
        $(document).ready(function(){
            $('#nav_menu').slicknav({prependTo:"#mobile_menu"});
        });
    </script>
</head>

<body>
    <header>
        <a href="index.php"><img src="images/logo3.jpg" alt="iHire Logo" ></a>
        <h3>SwiftConnections: Bridging Needs, Building Opportunities</h3>
        <h4>Welcome My Friend!</h4>
        
    </header>
    <nav id="mobile_menu"></nav>
    <nav id="nav_menu">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="postjob.php">Post Job</a>
                
            </li>
            <li><a href="job_details.php">Job Details</a>
                <ul>
                    <li><a href="send_message.php">View Your Messages</a>
                    </li>
                </ul>
            </li>
            <li><a href="userprofile.html">User Profile</a>
                <ul>
                    <li><a href="imagemaps/imagemaps.html">Map</a>
                        <ul>
                            <li><a href="https://www.tsa.gov/contact/lost-and-found" target="_blank" rel="noopener noreferrer">TSA lost and found</a></li>
                            <li><a href="https://disneyworld.disney.go.com/guest-services/lost-and-found/" target="_blank" rel="noopener noreferrer">Disney world lost and found</a></li>
                        </ul>
                    </li>  
                </ul>
            </li>
            <li class="lastitem"><a href="settings.html">Settings</a>
                <ul>
                    <li><a href="twotiernav.html">Finding Lost Items</a></li>
                    <li><a href="twotiernav.html">Preventing Loss</a></li>
                </ul>
            </li> 
            
            
            
        </ul>
    </nav>
		
   
    
    <?php
session_start();
include 'db_connection.php';

function sanitize_input($data) {
    return htmlspecialchars(trim($data));
}

// Retrieve messages for a job
function get_job_messages($job_id, $conn) {
    $sql = "SELECT messages.*, users.fname, users.lname 
            FROM messages 
            JOIN users ON messages.sender_id = users.id 
            WHERE job_id = ? 
            ORDER BY timestamp ASC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $job_id);
    $stmt->execute();
    return $stmt->get_result();
}

$sql_check_table = "SELECT 1 FROM postjobtable LIMIT 1";
$result = $conn->query($sql_check_table);

if ($result) {
    $sql_retrieve_data = "SELECT * FROM postjobtable";
    $stmt = $conn->prepare($sql_retrieve_data);
    $stmt->execute();
    $result = $stmt->get_result();

    echo "<html><body><table class='job-table' border='1'>";
    echo "<tr><th>Job ID</th><th>Description</th><th>Duration</th><th>Pay Rate</th><th>Name</th><th>Messages</th></tr>";

    while ($row = $result->fetch_assoc()) {
        $job_id = $row['id'];
        $description = $row['job_description'];
        $duration = $row['job_duration'];
        $rate = $row['pay_rate'];
        $first_name = $row['first_name'];
        $last_name = $row['last_name'];
        
        // Display job details
        echo "<tr><td>$job_id</td><td>$description</td><td>$duration</td><td>$rate</td><td>$first_name $last_name</td><td>";
        
        // Display messages related to the job
        $messages_result = get_job_messages($job_id, $conn);
        while ($message_row = $messages_result->fetch_assoc()) {
            $sender_fname = $message_row['fname'];
            $sender_lname = $message_row['lname'];
            echo "<p><strong>$sender_fname $sender_lname:</strong> {$message_row['message']}</p>";
        }
        
        // Message form
        echo "<form method='post' action='send_message.php' class='message-form'>";
        echo "<input type='hidden' name='sender_id' value='" . $_SESSION['user_id'] . "'>";
        echo "<input type='hidden' name='job_id' value='$job_id'>";
        echo "<textarea name='message' rows='2' cols='30' placeholder='Type your message'></textarea><br>";
        echo "<input type='submit' value='Send'>";
        echo "</form>";
        echo "</td></tr>";
    }
    echo "</table></body></html>";
} else {
    echo "Error: Table 'postjobtable' does not exist.";
}

$conn->close();
?>



    


    <br><br>     

        
        <button id="apply-button">Apply</button>
    

    <script src="script.js"></script>
    <footer>
        <p>You are not alone!</p>
    </footer>

</body>
</html>
