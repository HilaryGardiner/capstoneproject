<?php
// Start session
session_start();

// Include database connection
include 'db_connection.php';

// Check if admin is logged in (you can modify this condition based on your authentication mechanism)
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    header("Location: login.php");
    exit();
}

// Handle form submission to unlock user access
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = intval($_POST['user_id']);
    $sql_update = "UPDATE users SET background_check_completed = 1 WHERE id = ?";
    $stmt = $conn->prepare($sql_update);
    $stmt->bind_param("i", $user_id);
    if ($stmt->execute()) {
        $message = "User access unlocked successfully.";
    } else {
        $message = "Failed to unlock user access.";
    }
}
?>

<!doctype html>
<html lang="en">
<head>
    <title>Unlock User Access</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="styles/admin.css">
</head>
<body>
    <div class="container">
        <h1>Unlock User Access</h1>
        <?php if (isset($message)) echo "<p>$message</p>"; ?>
        <form method="POST">
            <label for="user_id">User ID:</label>
            <input type="number" id="user_id" name="user_id" required>
            <button type="submit">Unlock Access</button>
        </form>
    </div>
</body>
</html>
