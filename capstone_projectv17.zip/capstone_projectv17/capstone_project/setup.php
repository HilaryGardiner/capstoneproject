<?php
/*$host = 'localhost';     // Host name
$dbname = 'your_database';  // Database name
$user = 'your_user';     // Database user
$pass = 'your_password'; // Database password
$charset = 'utf8mb4';    // Character set*/

session_start();
include 'db_connection.php';

// Function to sanitize user input
function sanitize_input($data) {
    return htmlspecialchars(trim($data));
}

try {
    // Set up the DSN (Data Source Name)
    $dsn = "mysql:host=$host;dbname=$dbname;charset=$charset";

    // Create a new PDO instance
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,  // Set the PDO error mode to exception
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, // Fetch associative arrays by default
        PDO::ATTR_EMULATE_PREPARES => false,  // Turn off emulation mode for prepared statements
    ]);

    // SQL statement to create the payments table
    $paymentsTableSql = "
        CREATE TABLE IF NOT EXISTS payments (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            card_number VARCHAR(16) NOT NULL,
            cardholder_name VARCHAR(255) NOT NULL,
            expiry_date DATE NOT NULL,
            cvv VARCHAR(4) NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        );
    ";

    // SQL statement to create the password_resets table
    $passwordResetsTableSql = "
        CREATE TABLE IF NOT EXISTS password_resets (
            id INT AUTO_INCREMENT PRIMARY KEY,
            email VARCHAR(255) NOT NULL,
            token VARCHAR(255) NOT NULL,
            expires_at DATETIME NOT NULL
        );
    ";

    // Execute the SQL statements
    $pdo->exec($paymentsTableSql);
    echo "Table 'payments' created successfully.<br>";

    $pdo->exec($passwordResetsTableSql);
    echo "Table 'password_resets' created successfully.<br>";

} catch (PDOException $e) {
    // Handle any errors that occur during the connection or table creation
    echo "Error: " . $e->getMessage();
}
?>