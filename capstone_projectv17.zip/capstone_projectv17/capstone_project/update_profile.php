<?php
session_start();
include 'db_connection.php';

// Function to sanitize user input
function sanitize_input($data) {
    return htmlspecialchars(trim($data));
}

try {
    // Database connection
    $dsn = "mysql:host=$host;dbname=$dbname;charset=$charset";
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);

    // Assuming the user ID is stored in the session
    $user_id = $_SESSION['user_id'];

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Handle profile picture upload
        if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] == UPLOAD_ERR_OK) {
            $uploadDir = 'uploads/'; // Directory where the file will be uploaded

            // Check if the directory exists, if not, create it
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true); // Create directory with correct permissions
            }

            $profilePictureName = $user_id . '_' . basename($_FILES['profile_picture']['name']); // Ensure unique file names
            $uploadFile = $uploadDir . $profilePictureName;

            // Move the uploaded file to the destination directory
            if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $uploadFile)) {
                // Store the image path in the session (not in the database)
                $_SESSION['profile_picture'] = $uploadFile;
            } else {
                echo "Failed to upload profile picture.";
            }
        }

        // Sanitize and retrieve user input
        $fname = sanitize_input($_POST['fname']);
        $lname = sanitize_input($_POST['lname']);
        $email = sanitize_input($_POST['email']);
        $phone = sanitize_input($_POST['phone']);
        $address = sanitize_input($_POST['address']);
        $password = $_POST['password'];

        // Check if the password field is not empty
        if (!empty($password)) {
            // Hash the new password before updating it
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            // Update user profile information with the new password
            $stmt = $pdo->prepare("UPDATE users SET fname = ?, lname = ?, email = ?, phone = ?, address = ?, password = ? WHERE id = ?");
            $stmt->execute([$fname, $lname, $email, $phone, $address, $hashedPassword, $user_id]);
        } else {
            // Update user profile information without changing the password
            $stmt = $pdo->prepare("UPDATE users SET fname = ?, lname = ?, email = ?, phone = ?, address = ? WHERE id = ?");
            $stmt->execute([$fname, $lname, $email, $phone, $address, $user_id]);
        }

        // Update payment information
        $card_number = sanitize_input($_POST['card_number']);
        $cardholder_name = sanitize_input($_POST['cardholder_name']);
        $expiry_date = sanitize_input($_POST['expiry_date']);
        $cvv = sanitize_input($_POST['cvv']);

        // Convert expiry_date to proper format
        $expiry_date = $expiry_date . "-01"; // Adding the first day of the month to meet DATE format

        // Check if payment record exists for the user
        $stmt = $pdo->prepare("SELECT id FROM payments WHERE user_id = ?");
        $stmt->execute([$user_id]);
        $payment = $stmt->fetch();

        if ($payment) {
            // Update existing payment record
            $stmt = $pdo->prepare("UPDATE payments SET card_number = ?, cardholder_name = ?, expiry_date = ?, cvv = ? WHERE user_id = ?");
            $stmt->execute([$card_number, $cardholder_name, $expiry_date, $cvv, $user_id]);
        } else {
            // Insert new payment record
            $stmt = $pdo->prepare("INSERT INTO payments (user_id, card_number, cardholder_name, expiry_date, cvv) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$user_id, $card_number, $cardholder_name, $expiry_date, $cvv]);
        }

        echo "Profile updated successfully!";
        // Redirect to userprofile.php to show changes
        header("Location: userprofile.php");
        exit();
    }
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>
