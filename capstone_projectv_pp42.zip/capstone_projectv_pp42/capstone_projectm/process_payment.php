?>



<?php
session_start();
ob_start(); // Start output buffering

include 'db_connection.php';

//require __DIR__ . '/vendor/autoload.php'; // Include Stripe PHP SDK

require_once('vendor/autoload.php');



// Set your Stripe API keys
\Stripe\Stripe::setApiKey('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
');   // Replace with your actual secret key



// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id']; // Payer's ID

try {
    // Database connection
    $dsn = "mysql:host=$host;dbname=$dbname;charset=$charset";
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);

    // Fetch list of users for the receiver selection (excluding the payer)
    $stmt = $pdo->prepare("SELECT id, email FROM users WHERE id != ?");
    $stmt->execute([$user_id]);
    $users = $stmt->fetchAll();

    // If the form is submitted
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['receiver_id'], $_POST['amount'], $_POST['stripeToken'])) {
            $receiver_id = $_POST['receiver_id'];
            $amount = $_POST['amount'];
            $token = $_POST['stripeToken'];

            // Use Stripe to create the charge
            $charge = \Stripe\Charge::create([
                'amount' => $amount * 100, // Amount in cents
                'currency' => 'usd',
                'description' => 'Payment from ' . $user_id . ' to ' . $receiver_id,
                'source' => $token,
            ]);

            // Save transaction in the database
            $stmt = $pdo->prepare("INSERT INTO transactions (transaction_id, payer_id, receiver_id, amount, status, created_at) 
                                   VALUES (?, ?, ?, ?, ?, NOW())");
            $stmt->execute([$charge->id, $user_id, $receiver_id, $amount, $charge->status]);

            echo "Payment of $$amount was successful. Transaction ID: " . $charge->id;
        } else {
            echo "Error: Required payment information is missing.";
        }
    }
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    die("Error: " . $e->getMessage());
} catch (\Stripe\Exception\CardException $e) {
    error_log("Stripe error: " . $e->getError()->message);
    die("Error: " . $e->getError()->message);
} catch (Exception $e) {
    error_log("General error: " . $e->getMessage());
    die("Error: " . $e->getMessage());
}
ob_end_flush(); // End output buffering and flush output
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Process Payment</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <script src="https://js.stripe.com/v3/"></script>

    <link rel="shortcut icon" href="images/logo3.jpg">
    <link rel="stylesheet" href="styles/main.css">
    <link rel="stylesheet" href="styles/slicknav.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="js/jquery.slicknav.min.js"></script>
    <script>
        $(document).ready(function(){
            $('#nav_menu').slicknav({prependTo:"#mobile_menu"});
        });
    </script>
</head>
<body>

<header>
    <a href="indexhome.php"><img src="images/logo3.jpg" alt="Logo"></a>
    <h3 style="color: #f2972e;">SwiftConnections: Bridging Needs, Building Opportunities</h3>
    <h4>Welcome My Friend!</h4>
</header>

<nav id="mobile_menu"></nav>
<nav id="nav_menu">
    <ul>
        <li><a href="indexhome.php">Home</a></li>
        <li><a href="postjob.php">Post Job</a></li>
        <li><a href="#">Job Details</a>
            <ul>
                <li><a href="job_details.php">View Posted Jobs</a></li>
                <li><a href="messages.php">View Your Messages</a></li>
            </ul>
        </li>
        <li><a href="userprofile.php">User Profile</a></li>
        <li class="lastitem"><a href="process_payment.php">Payments</a></li>
    </ul>
</nav>

<form id="payment-form" method="post" action="process_payment.php">
    <label for="receiver_id">Select Receiver:</label>
    <select id="receiver_id" name="receiver_id" required>
        <?php foreach ($users as $user): ?>
            <option value="<?php echo $user['id']; ?>"><?php echo $user['email']; ?></option>
        <?php endforeach; ?>
    </select>

    <label for="amount">Amount ($):</label>
    <input type="number" id="amount" name="amount" required>

    <!-- Stripe Card Element -->
    <div id="card-element">
        <!-- Stripe injects the Card Element here -->
    </div>
    <button type="submit" id="submit">Pay Now</button>

    <!-- Display error message -->
    <div id="card-errors" role="alert"></div>
</form>

<script>
    var stripe = Stripe('pk_live_51Q37KRCBRQoEuYRBq6rtyBzpbqC0YlxCkavObueIQ7SfBKiKMcHDlrPaS9HpUt3q6oCf48HHrfLpBcYdcpcqSw9w00OsuP6H53'); // Replace with your actual publishable key
    var elements = stripe.elements();
    var card = elements.create('card', {
        hidePostalCode: true, // Optionally hide postal code
    });
    card.mount('#card-element');

    // Handle real-time validation errors from the card Element.
    card.on('change', function(event) {
        var displayError = document.getElementById('card-errors');
        if (event.error) {
            displayError.textContent = event.error.message;
        } else {
            displayError.textContent = '';
        }
    });

    function stripeTokenHandler(token) {
        var form = document.getElementById('payment-form');
        var hiddenInput = document.createElement('input');
        hiddenInput.setAttribute('type', 'hidden');
        hiddenInput.setAttribute('name', 'stripeToken');
        hiddenInput.setAttribute('value', token.id);
        form.appendChild(hiddenInput);
        form.submit();
    }

    // Add submit event listener to the form
    var form = document.getElementById('payment-form');

    form.addEventListener('submit', function (event) {
        event.preventDefault();

        stripe.createToken(card).then(function (result) {
            if (result.error) {
                var errorElement = document.getElementById('card-errors');
                errorElement.textContent = result.error.message;
            } else {
                // Call the function to handle the token
                stripeTokenHandler(result.token);
            }
        });
    });
</script>

</body>
</html>


