<?php
// Start session
session_start();

// Include database connection
include 'db_connection.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirect to login page if not logged in
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $job_description = $_POST["job_description"];
    $job_duration = $_POST["job_duration"];
    $pay_rate = $_POST["pay_rate"];
    $city = $_POST["city"];
    $state = $_POST["state"];

    // Ensure 'postjobtable' exists
    $sql_check_table = "SELECT 1 FROM postjobtable LIMIT 1";
    $result = $conn->query($sql_check_table);

    if (!$result) {
        // Create table if it doesn't exist
        $sql_create_table = "CREATE TABLE postjobtable (
            id INT AUTO_INCREMENT PRIMARY KEY,
            job_description VARCHAR(255) NOT NULL,
            job_duration INT NOT NULL,
            pay_rate DECIMAL(10, 2) NOT NULL,
            first_name VARCHAR(50) NOT NULL,
            last_name VARCHAR(50) NOT NULL,
            user_id INT NOT NULL,
            city VARCHAR(100) NOT NULL,
            state VARCHAR(100) NOT NULL,
            posted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";
        $conn->query($sql_create_table);
    }

    // Insert job into table
    $user_id = $_SESSION["user_id"];
    $first_name = $_SESSION["fname"];
    $last_name = $_SESSION["lname"];
    $sql_insert_data = "INSERT INTO postjobtable (job_description, job_duration, pay_rate, user_id, first_name, last_name, city, state)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql_insert_data);

    if (!$stmt) {
        die("Error preparing statement: " . $conn->error);
    }

    $stmt->bind_param("ssdissss", $job_description, $job_duration, $pay_rate, $user_id, $first_name, $last_name, $city, $state);

    if ($stmt->execute()) {
        //echo "Job posted successfully&nbsp;";
        echo '<span style="margin-left: 1em;"><b>Job posted successfully&nbsp;</b></span>';
        notifyUsers($city, $state, $job_description, $pay_rate);
    } else {
        echo "Error inserting data: " . $stmt->error;
    }
    $conn->close();
}


/**
 * Notify users in the same city and state
 */
function notifyUsers($city, $state, $job_description, $pay_rate) {
    global $conn;

    // Modify SQL to extract city and state from address
    $sql_users = "
        SELECT id 
        FROM users 
        WHERE 
            address LIKE CONCAT('%', ?, '%') 
            AND address LIKE CONCAT('%', ?, '%')
    ";
    $stmt = $conn->prepare($sql_users);

    if (!$stmt) {
        die("Error preparing statement: " . $conn->error);
    }

    $stmt->bind_param("ss", $city, $state);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $notifications_sent = false; // Track if any notifications were sent

        while ($row = $result->fetch_assoc()) {
            $user_id = $row['id'];
            $message = "New job posted: $job_description with pay rate of $$pay_rate/hour.";
            $sql_insert_notification = "INSERT INTO notifications (user_id, message) VALUES (?, ?)";
            $stmt_notification = $conn->prepare($sql_insert_notification);

            if (!$stmt_notification) {
                die("Error preparing notification statement: " . $conn->error);
            }

            $stmt_notification->bind_param("is", $user_id, $message);
            if ($stmt_notification->execute()) {
                $notifications_sent = true;
            } else {
                echo "Error sending notification to user ID $user_id: " . $stmt_notification->error;
            }
        }

        if ($notifications_sent) {
            echo "Notifications sent successfully to users in the specified area.";
        } else {
            echo "No notifications were sent due to an error.";
        }
    } else {
        echo "No users found in the specified area.";
    }
}


?>




<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
    <title>Post Job</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="images/logo3.jpg">
    <link rel="stylesheet" href="styles/main.css">
    <link rel="stylesheet" href="styles/slicknav.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="js/jquery.slicknav.min.js"></script>

	
    <script>
        $(document).ready(function(){
            $('#nav_menu').slicknav({prependTo:"#mobile_menu"});
        });
    </script>
   
</head>

<body>
	<header>
        <a href="index.php"><img src="images/logo3.jpg" alt="iHire Logo" ></a>
        <h3 style="color: #f2972e;">SwiftConnections: Bridging Needs, Building Opportunities</h3>
        <h4>Welcome My Friend!</h4>
        
    </header>
    <nav id="mobile_menu"></nav>
    <nav id="nav_menu">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="postjob.php">Post Job</a>
                
            </li>
            <li><a href="#">Job Details</a>
                <ul>
                    <li><a href="job_details.php">View Posted Jobs</a> </li>
                    <li><a href="messages.php">View Your Messages</a>
                    </li>
                </ul>
            </li>
            <li><a href="userprofile.php">User Profile</a>
                
            </li>
            <li class="lastitem"><a href="process_payment.php">Payments</a>
                
            </li>
            
            
            
        </ul>
    </nav>
	
    <form action="postjob.php" method="POST" onsubmit="return validateForm()">
        <label for="job_description">Job Description:</label>
        <textarea id="job_description" name="job_description" required placeholder="Ex. I need someone to walk my dog."></textarea><br><br>
        
        <label for="job_duration">Job Duration (hour):</label>
        <input type="text" id="job_duration" name="job_duration" required placeholder="Ex. type 2 for 2 hours"><br><br>
        
        <label for="pay_rate">Pay Rate ($/hour):</label>
        <input type="text" id="pay_rate" name="pay_rate" required placeholder="Ex. type 100 for $100.00/hour"><br><br>
        
        <label for="city">City:</label>
        <input type="text" id="city" name="city" required><br><br>

        <label for="state">State:</label>
        <input type="text" id="state" name="state" required placeholder="Ex. type AZ for Arizona or France for France"><br><br>

        <button type="submit">Post Job</button>
    </form>

    <script src="postjob_script.js"></script>

	

</body>

</html>
