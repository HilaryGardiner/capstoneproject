<?php 
session_start();
include 'db_connection.php'; // Your database connection file
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PayPal Payment</title>
    <script src="https://www.paypal.com/sdk/js?client-id=AX5LOI7bDCBn5XJVhy4SwZVihemHZJY9OYrDTnJxVyCbd8whkG7yTWXCZU_-2GeAQcGT6MQtkeX_ddPQ
&currency=USD"></script> 
</head>
<body>
    <h1>Service Payment</h1>
    <form id="payment-form">
        <label for="account_id">Service Provider PayPal Email:</label>
        <input type="email" id="account_id" name="account_id" required>
        <br><br>

        <label for="amount">Payment Amount (USD):</label>
        <input type="number" id="amount" name="amount" min="1" step="0.01" required>
        <br><br>

        <div id="paypal-button-container"></div> 
    </form>

    <script>
        paypal.Buttons({
            createOrder: function(data, actions) {
                const accountID = document.getElementById('account_id').value.trim();
                const amount = parseFloat(document.getElementById('amount').value);

                if (!accountID || isNaN(amount) || amount <= 0) {
                    alert('Invalid input: Check PayPal Email and Amount.');
                    return actions.reject();
                }

                return actions.order.create({
                    purchase_units: [{
                        amount: { value: amount.toFixed(2) },
                        payee: { email_address: accountID }
                    }]
                });
            },
            onApprove: function(data, actions) {
                return actions.order.capture().then(function(details) {
                    fetch('/process-payment.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            transaction_id: details.id,
                            account_id: details.purchase_units[0].payee.email_address,
                            amount: details.purchase_units[0].amount.value,
                            status: details.status
                        })
                    }).then(response => response.json())
                      .then(data => alert(data.message))
                      .catch(error => console.error('Error:', error));
                });
            },
            onError: function(err) {
                console.error('PayPal Checkout Error:', err);
                alert('Payment failed. Please try again.');
            }
        }).render('#paypal-button-container');
    </script>
</body>
</html>
