
<?php
session_start();
include 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Retrieve admin details from the database
    $sql = "SELECT id, password FROM admins WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $admin = $result->fetch_assoc();
        if (password_verify($password, $admin['password'])) {
            $_SESSION['is_admin'] = true;
            $_SESSION['admin_id'] = $admin['id'];
            header("Location: unlock_access.php");
            exit();
        }
    }
    $error_message = "Invalid username or password.";
}
?>
<!doctype html>
<html lang="en">
<head>
    <title>Admin Login</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="styles/admin.css">
</head>
<body>
    <form method="POST">
        <h1>Admin Login</h1>
        <?php if (isset($error_message)) echo "<p>$error_message</p>"; ?>
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>
        <button type="submit">Login</button>
    </form>
</body>
</html>
