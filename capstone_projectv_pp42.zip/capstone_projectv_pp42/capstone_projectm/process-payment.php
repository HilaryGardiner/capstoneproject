<?php
include 'db_connection.php'; 

header("Content-Type: application/json");

$input = json_decode(file_get_contents("php://input"), true);

if (!isset($input['transaction_id'], $input['account_id'], $input['amount'], $input['status'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid request parameters.']);
    exit;
}

$transactionID = $input['transaction_id'];
$accountID = $input['account_id'];
$amount = $input['amount'];
$status = $input['status'];

// Save payment details to database
$stmt = $conn->prepare("INSERT INTO payments (transaction_id, account_id, amount, status) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssds", $transactionID, $accountID, $amount, $status);

if ($stmt->execute()) {
    echo json_encode(['message' => 'Payment recorded successfully!']);
} else {
    echo json_encode(['error' => 'Database error. Payment not recorded.']);
}

$stmt->close();
$conn->close();
?>
