<?php
session_start();
include 'db_connection.php';

// Function to sanitize user input
function sanitize_input($data) {
    return htmlspecialchars(trim($data));
}

try {
    // Set up the DSN (Data Source Name)
    $dsn = "mysql:host=$host;dbname=$dbname;charset=$charset";

    // Create a new PDO instance
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,  // Set the PDO error mode to exception
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, // Fetch associative arrays by default
        PDO::ATTR_EMULATE_PREPARES => false,  // Turn off emulation mode for prepared statements
    ]);

    // SQL statement to create the users table
    $usersTableSql = "
    CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY, 
        fname VARCHAR(50) NOT NULL, 
        lname VARCHAR(50) NOT NULL, 
        email VARCHAR(100) NOT NULL UNIQUE, 
        phone VARCHAR(20), 
        address TEXT, 
        password VARCHAR(255) NOT NULL, 
        profile_picture VARCHAR(255), 
        background_check_completed BOOLEAN DEFAULT FALSE, 
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, 
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    );
    ";

    // SQL statement to create the admins table
    $adminsTableSql = "
    CREATE TABLE IF NOT EXISTS admins (
        id INT AUTO_INCREMENT PRIMARY KEY, 
        username VARCHAR(255) NOT NULL UNIQUE, 
        password VARCHAR(255) NOT NULL, 
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    ";

    // SQL statement to create the payments table
    $paymentsTableSql = "
    CREATE TABLE IF NOT EXISTS payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    transaction_id VARCHAR(255) NOT NULL UNIQUE,
    account_id INT NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    status VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (account_id) REFERENCES users(id) ON DELETE CASCADE
    );
    ";

    
    // SQL statement to create the password_resets table
    $passwordResetsTableSql = "
    CREATE TABLE IF NOT EXISTS password_resets (
        id INT AUTO_INCREMENT PRIMARY KEY,
        email VARCHAR(255) NOT NULL,
        token VARCHAR(255) NOT NULL,
        expires_at DATETIME NOT NULL
    );
    ";

    // SQL statement to create the transactions table
    $transactionsTableSql = "
    CREATE TABLE IF NOT EXISTS transactions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        transaction_id VARCHAR(255) NOT NULL,
        payer_id INT NOT NULL,
        receiver_email VARCHAR(255) NOT NULL,
        gross_amount DECIMAL(10, 2) NOT NULL,
        platform_fee DECIMAL(10, 2) NOT NULL,
        net_amount DECIMAL(10, 2) NOT NULL,
        status VARCHAR(50) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    ";

    // SQL statement to create the notifications table
    $notificationsTableSql = "
    CREATE TABLE IF NOT EXISTS notifications (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        message TEXT NOT NULL,
        is_read BOOLEAN DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    ";

    // SQL statement to create the paypalusers table
    $paypalUsersTableSql = "
    CREATE TABLE IF NOT EXISTS paypalusers (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        paypal_email VARCHAR(255) NOT NULL UNIQUE,
        user_id INT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    ";

    // Execute the SQL statements
    $pdo->exec($usersTableSql);
    echo "Table 'users' created successfully.<br>";

    $pdo->exec($adminsTableSql);
    echo "Table 'admins' created successfully.<br>";

    $pdo->exec($paymentsTableSql);
    echo "Table 'payments' created successfully.<br>";

    $pdo->exec($passwordResetsTableSql);
    echo "Table 'password_resets' created successfully.<br>";

    $pdo->exec($transactionsTableSql);
    echo "Table 'transactions' created successfully.<br>";

    $pdo->exec($notificationsTableSql);
    echo "Table 'notifications' created successfully.<br>";

    $pdo->exec($paypalUsersTableSql);
    echo "Table 'paypalusers' created successfully.<br>";

} catch (PDOException $e) {
    // Handle any errors that occur during the connection or table creation
    echo "Error: " . $e->getMessage();
}
?>
