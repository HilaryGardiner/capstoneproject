<?php
include 'db_connection.php'; 

$rawData = file_get_contents('php://input');
$event = json_decode($rawData, true);

file_put_contents('paypal_webhook_logs.txt', $rawData . PHP_EOL, FILE_APPEND);

if ($event['event_type'] === 'PAYMENT.CAPTURE.COMPLETED') {
    $transactionID = $event['resource']['id'];
    $accountID = $event['resource']['payee']['email_address'];
    $amount = $event['resource']['amount']['value'];
    $status = $event['resource']['status'];

    $stmt = $conn->prepare("UPDATE payments SET status=? WHERE transaction_id=?");
    $stmt->bind_param("ss", $status, $transactionID);
    $stmt->execute();
    $stmt->close();
}

http_response_code(200);
?>
