<!DOCTYPE html>
<html lang="en">
<head>
	<title>Job Details</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial scale=1">
	<link rel="shortcut icon" href="images/logo3.jpg">
	<link rel="stylesheet" href="styles/main.css">
	<link rel="stylesheet" href="styles/slicknav.css">
    <link rel="stylesheet" href="table_form.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="js/jquery.slicknav.min.js"></script>
    <script>
        $(document).ready(function(){
            $('#nav_menu').slicknav({prependTo:"#mobile_menu"});
        });
    </script>
</head>

<body style="margin: 15px auto; width: 80%;">

    <header>
        <a href="index.php"><img src="images/logo3.jpg" alt="iHire Logo" ></a>
        <h3>SwiftConnections: Bridging Needs, Building Opportunities</h3>
        <h4>Welcome My Friend!</h4>
        
    </header>
    <nav id="mobile_menu"></nav>
    <nav id="nav_menu">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="postjob.php">Post Job</a>
                
            </li>
            <li><a href="#">Job Details</a>
                <ul>
                    <li><a href="job_details.php">View Posted Jobs</a> </li>
                    <li><a href="messages.php">View Your Messages</a>
                    </li>
                </ul>
            </li>
            <li><a href="userprofile.php">User Profile</a>
                
            </li>
            <li class="lastitem"><a href="process_payment.php">Payments</a>
                
            </li>
            
            
            
        </ul>
    </nav>

    
    <?php
session_start();
include 'db_connection.php';

function sanitize_input($data) {
    return htmlspecialchars(trim($data));
}

function create_messages_table($conn) {
    $sql_check_table = "SHOW TABLES LIKE 'messages'";
    $result = $conn->query($sql_check_table);
    if ($result->num_rows == 0) {
        $sql_create_table = "CREATE TABLE messages (
            id INT AUTO_INCREMENT PRIMARY KEY,
            sender_id INT NOT NULL,
            receiver_id INT NOT NULL,
            job_id INT NOT NULL,
            poster_id INT NOT NULL,
            message TEXT NOT NULL,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (sender_id) REFERENCES users(id),
            FOREIGN KEY (receiver_id) REFERENCES users(id),
            FOREIGN KEY (job_id) REFERENCES postjobtable(id),
            FOREIGN KEY (poster_id) REFERENCES users(id)
        )";
        $conn->query($sql_create_table);
    }
}

create_messages_table($conn);

if (!isset($_SESSION['user_id'])) {
    die("<div>You must be logged in to view messages.</div>");
}

$user_id = $_SESSION['user_id'];
$job_id = isset($_GET['job_id']) ? sanitize_input($_GET['job_id']) : null;
$receiver_id = isset($_GET['receiver_id']) ? sanitize_input($_GET['receiver_id']) : null;
$poster_id = isset($_GET['poster_id']) ? sanitize_input($_GET['poster_id']) : null;

$sql_user_jobs = "SELECT DISTINCT job_id, poster_id FROM messages WHERE sender_id = ?";
$stmt_user_jobs = $conn->prepare($sql_user_jobs);
$stmt_user_jobs->bind_param("i", $user_id);
$stmt_user_jobs->execute();
$user_jobs = $stmt_user_jobs->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt_user_jobs->close();

$sql_posted_jobs = "SELECT id FROM postjobtable WHERE user_id = ?";
$stmt_posted_jobs = $conn->prepare($sql_posted_jobs);
$stmt_posted_jobs->bind_param("i", $user_id);
$stmt_posted_jobs->execute();
$posted_jobs = $stmt_posted_jobs->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt_posted_jobs->close();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['message']) && $job_id && $receiver_id) {
    $message = sanitize_input($_POST['message']);
    if ($message != "") {
        $sql_get_poster = "SELECT user_id FROM postjobtable WHERE id = ?";
        $stmt_get_poster = $conn->prepare($sql_get_poster);
        $stmt_get_poster->bind_param("i", $job_id);
        $stmt_get_poster->execute();
        $poster_id = $stmt_get_poster->get_result()->fetch_assoc()['user_id'] ?? null;
        $stmt_get_poster->close();

        $stmt = $conn->prepare("INSERT INTO messages (sender_id, receiver_id, job_id, poster_id, message) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("iiiis", $user_id, $receiver_id, $job_id, $poster_id, $message);
        $stmt->execute();
        $stmt->close();
    }
}

echo "<html><body>";
echo "<h3>Jobs You Responded To</h3>";
if (!empty($user_jobs)) {
    foreach ($user_jobs as $user_job) {
        $poster_id = $user_job['poster_id'] ?? 'unknown';
        echo "<a href='messages.php?job_id={$user_job['job_id']}&receiver_id=$user_id&poster_id=$poster_id'>Job ID: {$user_job['job_id']}</a><br>";
    }
} else {
    echo "You have not responded to any jobs.<br>";
}

echo "<h3>Your Posted Jobs</h3>";
if (!empty($posted_jobs)) {
    foreach ($posted_jobs as $posted_job) {
        echo "<a href='messages.php?job_id={$posted_job['id']}&receiver_id=$user_id'>Job ID: {$posted_job['id']}</a><br>";
    }
} else {
    echo "You have not posted any jobs.<br>";
}

if ($job_id && $receiver_id) {
    $sql = "SELECT messages.*, users.fname, users.lname 
            FROM messages 
            JOIN users ON messages.sender_id = users.id 
            WHERE job_id = ? 
              AND (sender_id = ? OR receiver_id = ? OR poster_id = ?) 
            ORDER BY timestamp ASC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iiii", $job_id, $user_id, $user_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    echo "<h3>Messages for Job ID: $job_id</h3>";
    echo "<form method='post' action='messages.php?job_id=$job_id&receiver_id=$receiver_id&poster_id=$poster_id'>
          <textarea name='message' rows='4' cols='50' placeholder='Type your message'></textarea><br>
          <input type='submit' value='Send'>
          </form><br>";

    while ($row = $result->fetch_assoc()) {
        $sender_name = $row['fname'] . " " . $row['lname'];
        echo "<p><strong>$sender_name:</strong> " . $row['message'] . " <em>[" . $row['timestamp'] . "]</em></p>";
    }
    $stmt->close();
}

echo "</body></html>";
?>
   


<br><br>     

        
       <!-- <button id="apply-button">Apply</button>-->
    

   <!-- <script src="script.js"></script>-->
    <footer>
        <p>You are not alone!</p>
    </footer>

</body>
</html>