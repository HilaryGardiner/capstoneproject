


<!DOCTYPE html>
<html lang="en">
<head>
	<title>Job Details</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial scale=1">
	<link rel="shortcut icon" href="images/logo3.jpg">
	<link rel="stylesheet" href="styles/main.css">
	<link rel="stylesheet" href="styles/slicknav.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="js/jquery.slicknav.min.js"></script>
    <script>
        $(document).ready(function(){
            $('#nav_menu').slicknav({prependTo:"#mobile_menu"});
        });
    </script>
</head>

<body>
    <header>
        <a href="index.php"><img src="images/logo3.jpg" alt="iHire Logo" ></a>
        <h3>SwiftConnections: Bridging Needs, Building Opportunities</h3>
        <h4>Welcome My Friend!</h4>
        
    </header>
    <nav id="mobile_menu"></nav>
    <nav id="nav_menu">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="postjob.php">Post Job</a>
                
            </li>
            <li><a href="job_details.php">Job Details</a>
                <ul>
                    <li><a href="send_message.php">View Your Messages</a>
                    </li>
                </ul>
            </li>
            <li><a href="userprofile.html">User Profile</a>
                <ul>
                    <li><a href="imagemaps/imagemaps.html">Map</a>
                        <ul>
                            <li><a href="https://www.tsa.gov/contact/lost-and-found" target="_blank" rel="noopener noreferrer">TSA lost and found</a></li>
                            <li><a href="https://disneyworld.disney.go.com/guest-services/lost-and-found/" target="_blank" rel="noopener noreferrer">Disney world lost and found</a></li>
                        </ul>
                    </li>  
                </ul>
            </li>
            <li class="lastitem"><a href="settings.html">Settings</a>
                <ul>
                    <li><a href="twotiernav.html">Finding Lost Items</a></li>
                    <li><a href="twotiernav.html">Preventing Loss</a></li>
                </ul>
            </li> 
            
            
            
        </ul>
    </nav>

    
    <?php
session_start();
include 'db_connection.php';

function sanitize_input($input) {
    return htmlspecialchars(trim($input));
}

// Function to create the messages table if it doesn't exist
function create_messages_table($conn) {
    $sql_check_table = "SHOW TABLES LIKE 'messages'";
    $result = $conn->query($sql_check_table);
    if ($result->num_rows == 0) {
        // Table does not exist, create it
        $sql_create_table = "CREATE TABLE messages (
            id INT AUTO_INCREMENT PRIMARY KEY,
            sender_id INT NOT NULL,
            receiver_id INT NOT NULL,
            job_id INT NOT NULL,
            message TEXT NOT NULL,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";
        if (!$conn->query($sql_create_table)) {
            echo "Error creating table: " . $conn->error;
        }
    }
}

// Call the function to check and create the table
create_messages_table($conn);

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    die("<div>You must be logged in to send messages.</div></body></html>");
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['job_id'], $_POST['message'], $_POST['receiver_id'])) {
    $sender_id = $_SESSION['user_id'];
    $receiver_id = sanitize_input($_POST['receiver_id']);
    $job_id = sanitize_input($_POST['job_id']);
    $message = sanitize_input($_POST['message']);

    // Insert message into the database
    $sql_insert_message = "INSERT INTO messages (sender_id, receiver_id, job_id, message) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql_insert_message);
    if ($stmt !== false) {
        $stmt->bind_param("iiis", $sender_id, $receiver_id, $job_id, $message);
        if ($stmt->execute()) {
            echo "Message sent successfully.";
        } else {
            echo "Error sending message: " . $stmt->error;
        }
    } else {
        echo "Error preparing statement: " . $conn->error;
    }
}

// Retrieve and display messages
if (isset($_POST['job_id'])) {
    $job_id = sanitize_input($_POST['job_id']);

    // Retrieve messages for the job
    $sql = "SELECT messages.*, users.fname, users.lname 
            FROM messages 
            JOIN users ON messages.sender_id = users.id 
            WHERE job_id = ? 
            ORDER BY timestamp ASC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $job_id);
    $stmt->execute();
    $messages_result = $stmt->get_result();

    echo "<html><body><div class='messages'>";
    while ($message_row = $messages_result->fetch_assoc()) {
        $sender_fname = $message_row['fname'];
        $sender_lname = $message_row['lname'];
        echo "<p><strong>$sender_fname $sender_lname:</strong> {$message_row['message']}</p>";
    }
    echo "</div></body></html>";
}

$conn->close();
?>



<br><br>     

        
        <button id="apply-button">Apply</button>
    

    <script src="script.js"></script>
    <footer>
        <p>You are not alone!</p>
    </footer>

</body>
</html>