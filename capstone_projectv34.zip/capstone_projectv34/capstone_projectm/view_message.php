<?php
session_start();
include 'db_connection.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirect to login page if user is not logged in
    exit();
}

// Function to get user's messages
function get_messages($user_id, $conn) {
    $sql = "SELECT * FROM messages WHERE (sender_id = ? OR recipient_id = ?) ORDER BY timestamp DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $user_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Get messages for the logged-in user
$user_id = $_SESSION['user_id'];
$user_messages = get_messages($user_id, $conn);

// Display messages
echo "<h2>Your Messages</h2>";
if (!empty($user_messages)) {
    echo "<ul>";
    foreach ($user_messages as $message) {
        $message_id = $message['id'];
        $sender_id = $message['sender_id'];
        $recipient_id = $message['recipient_id'];
        $message_content = $message['message'];
        $timestamp = $message['timestamp'];
        $message_sender = ($sender_id == $user_id) ? "You" : "Sender"; // Replace "Sender" with actual sender name
        echo "<li><strong>$message_sender:</strong> $message_content <span>($timestamp)</span> <a href='respond_message.php?message_id=$message_id'>Respond</a></li>";
    }
    echo "</ul>";
} else {
    echo "No messages found.";
}

// Close connection
$conn->close();
?>
