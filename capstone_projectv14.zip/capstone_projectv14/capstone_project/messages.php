<!DOCTYPE html>
<html lang="en">
<head>
	<title>Job Details</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial scale=1">
	<link rel="shortcut icon" href="images/logo3.jpg">
	<link rel="stylesheet" href="styles/main.css">
	<link rel="stylesheet" href="styles/slicknav.css">
    <link rel="stylesheet" href="table_form.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="js/jquery.slicknav.min.js"></script>
    <script>
        $(document).ready(function(){
            $('#nav_menu').slicknav({prependTo:"#mobile_menu"});
        });
    </script>
</head>

<body>
    <header>
        <a href="index.php"><img src="images/logo3.jpg" alt="iHire Logo" ></a>
        <h3>SwiftConnections: Bridging Needs, Building Opportunities</h3>
        <h4>Welcome My Friend!</h4>
        
    </header>
    <nav id="mobile_menu"></nav>
    <nav id="nav_menu">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="postjob.php">Post Job</a>
                
            </li>
            <li><a href="job_details.php">Job Details</a>
                <ul>
                   <!-- <li><a href="send_message.php">View Your Messages</a>-->
                    <li><a href="messages.php">View Your Messages</a>
                    </li>
                </ul>
            </li>
            <li><a href="userprofile.html">User Profile</a>
                <ul>
                    <li><a href="imagemaps/imagemaps.html">Map</a>
                        <ul>
                            <li><a href="https://www.tsa.gov/contact/lost-and-found" target="_blank" rel="noopener noreferrer">TSA lost and found</a></li>
                            <li><a href="https://disneyworld.disney.go.com/guest-services/lost-and-found/" target="_blank" rel="noopener noreferrer">Disney world lost and found</a></li>
                        </ul>
                    </li>  
                </ul>
            </li>
            <li class="lastitem"><a href="settings.html">Settings</a>
                <ul>
                    <li><a href="twotiernav.html">Finding Lost Items</a></li>
                    <li><a href="twotiernav.html">Preventing Loss</a></li>
                </ul>
            </li> 
            
            
            
        </ul>
    </nav>


   
<?php
session_start();
include 'db_connection.php';

function sanitize_input($data) {
    return htmlspecialchars(trim($data));
}

function create_messages_table($conn) {
    $sql_check_table = "SHOW TABLES LIKE 'messages'";
    $result = $conn->query($sql_check_table);
    if ($result->num_rows == 0) {
        $sql_create_table = "CREATE TABLE messages (
            id INT AUTO_INCREMENT PRIMARY KEY,
            sender_id INT NOT NULL,
            receiver_id INT NOT NULL,
            job_id INT NOT NULL,
            message TEXT NOT NULL,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (sender_id) REFERENCES users(id),
            FOREIGN KEY (receiver_id) REFERENCES users(id),
            FOREIGN KEY (job_id) REFERENCES postjobtable(id)
        )";
        if (!$conn->query($sql_create_table)) {
            echo "Error creating table: " . $conn->error;
        }
    } else {
        $columns = ['sender_id', 'receiver_id', 'job_id', 'message', 'timestamp'];
        foreach ($columns as $column) {
            $sql_check_column = "SHOW COLUMNS FROM messages LIKE '$column'";
            $column_result = $conn->query($sql_check_column);
            if ($column_result->num_rows == 0) {
                if ($column == 'timestamp') {
                    $sql_alter_table = "ALTER TABLE messages ADD COLUMN $column TIMESTAMP DEFAULT CURRENT_TIMESTAMP";
                } else {
                    $sql_alter_table = "ALTER TABLE messages ADD COLUMN $column INT NOT NULL";
                }
                if (!$conn->query($sql_alter_table)) {
                    echo "Error altering table: " . $conn->error;
                }
            }
        }
    }
}

create_messages_table($conn);

if (!isset($_SESSION['user_id'])) {
    die("<div>You must be logged in to view messages.</div></body></html>");
}

$user_id = $_SESSION['user_id'];

if (isset($_GET['job_id']) && isset($_GET['receiver_id'])) {
    $job_id = sanitize_input($_GET['job_id']);
    $receiver_id = sanitize_input($_GET['receiver_id']);
} else {
    // Fetch the first job the user posted and the corresponding receiver
    $sql_get_first_job = "SELECT id AS job_id, user_id AS receiver_id 
                          FROM postjobtable 
                          WHERE user_id = ? 
                          LIMIT 1";
    $stmt_get_first_job = $conn->prepare($sql_get_first_job);
    $stmt_get_first_job->bind_param("i", $user_id);
    $stmt_get_first_job->execute();
    $result_first_job = $stmt_get_first_job->get_result();

    if ($result_first_job->num_rows > 0) {
        $first_job = $result_first_job->fetch_assoc();
        $job_id = $first_job['job_id'];
        $receiver_id = $first_job['receiver_id'];
    } else {
        die("<div>No jobs found for the user.</div></body></html>");
    }
}

$sql_check_user_role = "SELECT * FROM postjobtable WHERE id = ? AND (user_id = ? OR user_id = ?)";
$stmt_check_user_role = $conn->prepare($sql_check_user_role);
if ($stmt_check_user_role) {
    $stmt_check_user_role->bind_param("iii", $job_id, $user_id, $receiver_id);
    $stmt_check_user_role->execute();
    $result_check_user_role = $stmt_check_user_role->get_result();

    if ($result_check_user_role->num_rows == 0) {
        die("<div>You do not have permission to view these messages.</div></body></html>");
    }
    $stmt_check_user_role->close();
} else {
    die("Error preparing statement: " . $conn->error);
}

if (isset($_POST['message'])) {
    $message = sanitize_input($_POST['message']);
    if ($message != "") {
        $stmt = $conn->prepare("INSERT INTO messages (sender_id, receiver_id, job_id, message) VALUES (?, ?, ?, ?)");
        if ($stmt) {
            $stmt->bind_param("iiis", $user_id, $receiver_id, $job_id, $message);
            if (!$stmt->execute()) {
                echo "Error: " . $stmt->error;
            }
            $stmt->close();
        } else {
            echo "Error preparing statement: " . $conn->error;
        }
    }
}

$sql = "SELECT messages.*, users.fname, users.lname 
        FROM messages 
        JOIN users ON messages.sender_id = users.id 
        WHERE job_id = ? AND (sender_id = ? OR receiver_id = ?) AND (receiver_id = ? OR sender_id = ?) 
        ORDER BY timestamp ASC";
$stmt = $conn->prepare($sql);
if ($stmt) {
    $stmt->bind_param("iiiii", $job_id, $user_id, $user_id, $receiver_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    echo "<h3>Messages for Job ID: $job_id</h3>";

    echo "<form method='post' action='messages.php?job_id=$job_id&receiver_id=$receiver_id'>
          <textarea name='message' rows='4' cols='50' placeholder='Type your message'></textarea><br>
          <input type='submit' value='Send'>
          </form><br>";

    while ($row = $result->fetch_assoc()) {
        $sender_name = $row['fname'] . " " . $row['lname'];
        echo "<p><strong>$sender_name:</strong> " . $row['message'] . " <em>[" . $row['timestamp'] . "]</em></p>";
    }

    $stmt->close();
} else {
    echo "Error preparing statement: " . $conn->error;
}

$conn->close();
?>




<br><br>     

        
       <!-- <button id="apply-button">Apply</button>-->
    

   <!-- <script src="script.js"></script>-->
    <footer>
        <p>You are not alone!</p>
    </footer>

</body>
</html>