<?php
// Start session
session_start();

// Include database connection
include 'db_connection.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirect to login page if not logged in
    exit();
}



if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $job_description = $_POST["job_description"];
    $job_duration = $_POST["job_duration"]; // Assuming job duration is in minutes (e.g., 120 for 2 hours)
    $pay_rate = $_POST["pay_rate"];
    $city = $_POST["city"];
    $state = $_POST["state"];

    // Check if the table 'postjobtable' exists
    $sql_check_table = "SELECT 1 FROM postjobtable LIMIT 1";
    $result = $conn->query($sql_check_table);

    if (!$result) {
        // Table does not exist, create it
        $sql_create_table = "CREATE TABLE postjobtable (
            id INT AUTO_INCREMENT PRIMARY KEY,
            job_description VARCHAR(255) NOT NULL,
            job_duration INT NOT NULL,
            pay_rate DECIMAL(10, 2) NOT NULL,
            first_name VARCHAR(50) NOT NULL,
            last_name VARCHAR(50) NOT NULL,
            user_id INT NOT NULL,
            city VARCHAR(100) NOT NULL,
            state VARCHAR(100) NOT NULL,
            posted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";

        try {
            $conn->query($sql_create_table);
            echo "Table 'postjobtable' created successfully";
        } catch (Exception $e) {
            echo "Error creating table: " . $e->getMessage();
        }
    }

    // Get user's ID and name (assuming you have a login system)
    $user_id = $_SESSION["user_id"]; // Replace with actual session variable
    $first_name = $_SESSION["fname"]; // Replace with actual session variable
    $last_name = $_SESSION["lname"];  // Replace with actual session variable

    // Insert data into the table
    $sql_insert_data = "INSERT INTO postjobtable (job_description, job_duration, pay_rate, user_id, first_name, last_name, city, state)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    try {
        $stmt = $conn->prepare($sql_insert_data);
        $stmt->bind_param("ssdissss", $job_description, $job_duration, $pay_rate, $user_id, $first_name, $last_name, $city, $state);
        if ($stmt->execute()) {
            echo "New record inserted successfully";
        } else {
            echo "Error inserting data: " . $stmt->error;
        }
    } catch (Exception $e) {
        echo "Error inserting data: " . $e->getMessage();
    }

    // Debugging: Display form data
    var_dump($_POST);
    // Close connection
    $conn->close();
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
    <title>Post Job</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="images/logo3.jpg">
    <link rel="stylesheet" href="styles/main.css">
    <link rel="stylesheet" href="styles/slicknav.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="js/jquery.slicknav.min.js"></script>

	
    <script>
        $(document).ready(function(){
            $('#nav_menu').slicknav({prependTo:"#mobile_menu"});
        });
    </script>
   
</head>

<body>
	<header>
        <a href="index.php"><img src="images/logo3.jpg" alt="iHire Logo" ></a>
        <h3>SwiftConnections: Bridging Needs, Building Opportunities</h3>
        <h4>Welcome My Friend!</h4>
        
    </header>
    <nav id="mobile_menu"></nav>
    <nav id="nav_menu">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="postjob.php">Post Job</a>
                
            </li>
            <li><a href="#">Job Details</a>
                <ul>
                    <li><a href="job_details.php">View Posted Jobs</a> </li>
                    <li><a href="messages.php">View Your Messages</a>
                    </li>
                </ul>
            </li>
            <li><a href="userprofile.php">User Profile</a>
                
            </li>
            <li class="lastitem"><a href="process_payment.php">Payments</a>
                
            </li>
            
            
            
        </ul>
    </nav>
	
    <form action="postjob.php" method="POST" onsubmit="return validateForm()">
        <label for="job_description">Job Description:</label>
        <textarea id="job_description" name="job_description" required></textarea><br><br>
        
        <label for="job_duration">Job Duration:</label>
        <input type="text" id="job_duration" name="job_duration" required><br><br>
        
        <label for="pay_rate">Pay Rate:</label>
        <input type="text" id="pay_rate" name="pay_rate" required><br><br>
        
        <label for="city">City:</label>
        <input type="text" id="city" name="city" required><br><br>

        <label for="state">State:</label>
        <input type="text" id="state" name="state" required placeholder="Ex. Arizona"><br><br>

        <button type="submit">Post Job</button>
    </form>

    <script src="postjob_script.js"></script>

	

</body>

</html>
