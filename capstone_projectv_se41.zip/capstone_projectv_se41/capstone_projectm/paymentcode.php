<?php 
session_start();
include 'db_connection.php'; // Your database connection file

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stripe Payment</title>
    <script src="https://js.stripe.com/v3/"></script> <!-- Load Stripe.js library -->
</head>
<body>
    <h1>Service Payment</h1>
    <form id="payment-form">
        <label for="account_id">Service Provider Account ID:</label>
        <input type="text" id="account_id" name="account_id" required>
        <br><br>

        <label for="amount">Payment Amount (USD):</label>
        <input type="number" id="amount" name="amount" min="1" step="0.01" required>
        <br><br>

        <div id="card-element"></div>
        <div id="card-errors" role="alert" style="color: red;"></div>
        <br>

        <button id="submit-button" type="submit">Pay</button>
    </form>

    <script>
        const stripe = Stripe('pk_live_8484848488490dkdk'); // Publishable key from Stripe
        const elements = stripe.elements();
        const cardElement = elements.create('card');
        cardElement.mount('#card-element');

        const form = document.getElementById('payment-form');
        const submitButton = document.getElementById('submit-button');

        form.addEventListener('submit', async (event) => {
        event.preventDefault();
        submitButton.disabled = true;

        const accountID = document.getElementById('account_id').value.trim();
        const amount = parseFloat(document.getElementById('amount').value);

        if (!accountID || isNaN(amount) || amount <= 0) {
        alert('Invalid input: Check Account ID and Amount.');
        submitButton.disabled = false;
        return;
    }

    const amountInCents = Math.round(amount * 100);

    try {
        const response = await fetch('/create-payment-intent.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ account_id: accountID, amount: amountInCents }),
        });

        const textResponse = await response.text(); // Get raw response
        console.log("Raw Response:", textResponse); // Log response for debugging

        let jsonResponse;
        try {
            jsonResponse = JSON.parse(textResponse); // Parse JSON
        } catch (err) {
            throw new Error('Server returned invalid JSON.');
        }

        if (jsonResponse.error) throw new Error(jsonResponse.error);

        const { clientSecret } = jsonResponse;
        const { error: stripeError } = await stripe.confirmCardPayment(clientSecret, {
            payment_method: { card: cardElement },
        });

        if (stripeError) throw new Error(stripeError.message);

        alert('Payment successful!');
        form.reset();
    } catch (err) {
        document.getElementById('card-errors').textContent = err.message;
        console.error("Error:", err);
    } finally {
        submitButton.disabled = false;
    }
});

    </script>
</body>
</html>
