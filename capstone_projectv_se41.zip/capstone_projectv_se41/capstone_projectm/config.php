<?php /*
define('STRIPE_SECRET_KEY', getenv('STRIPE_SECRET_KEY'));
define('STRIPE_WEBHOOK_SECRET', getenv('STRIPE_WEBHOOK_SECRET'));*/
?>



<?php
session_start();
include 'db_connection.php'; // Your database connection file

// Store your Stripe API keys directly in config.php (NOT recommended for production)
define('STRIPE_SECRET_KEY', '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');
define('STRIPE_WEBHOOK_SECRET', 'whsec_pa8Gg5NnwVhWCXaA88ypcKvzfpkIhrPk');
?>
