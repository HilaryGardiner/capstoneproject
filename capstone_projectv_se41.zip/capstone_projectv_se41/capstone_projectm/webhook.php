<?php

include 'db_connection.php'; // Your database connection file

require __DIR__ . '/vendor/autoload.php';
require __DIR__ . '/config.php';

\Stripe\Stripe::setApiKey(STRIPE_SECRET_KEY);

$payload = file_get_contents('php://input');
$sig_header = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '';
$event = null;

try {
    $event = \Stripe\Webhook::constructEvent($payload, $sig_header, STRIPE_WEBHOOK_SECRET);
} catch (\Stripe\Exception\SignatureVerificationException $e) {
    http_response_code(400);
    exit;
} catch (\UnexpectedValueException $e) {
    http_response_code(400);
    exit;
}

if ($event['type'] === 'payment_intent.succeeded') {
    $paymentIntent = $event['data']['object'];
    $transactionID = $paymentIntent['id'];
    $amount = $paymentIntent['amount'];
    $accountID = $paymentIntent['transfer_data']['destination'];

    file_put_contents('payment_logs.txt', "Transaction Successful: $transactionID, Amount: $amount, To: $accountID\n", FILE_APPEND);
}

http_response_code(200);
?>
