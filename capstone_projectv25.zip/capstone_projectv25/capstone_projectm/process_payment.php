<?php
session_start();
include 'db_connection.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id']; // Payer ID

try {
    // Database connection
    $dsn = "mysql:host=$host;dbname=$dbname;charset=$charset";
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);

    // Fetch list of users for the receiver selection (excluding the payer)
    $stmt = $pdo->prepare("SELECT id, email FROM users WHERE id != ?");
    $stmt->execute([$user_id]);
    $users = $stmt->fetchAll();

} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Post Job</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="images/logo3.jpg">
    <link rel="stylesheet" href="styles/main.css">
    <link rel="stylesheet" href="styles/slicknav.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="js/jquery.slicknav.min.js"></script>
    <script>
        $(document).ready(function(){
            $('#nav_menu').slicknav({prependTo:"#mobile_menu"});
        });
    </script>
</head>
<body>
<header>
    <a href="index.php"><img src="images/logo3.jpg" alt="iHire Logo"></a>
    <h3>SwiftConnections: Bridging Needs, Building Opportunities</h3>
    <h4>Welcome My Friend!</h4>
</header>
<nav id="mobile_menu"></nav>
<nav id="nav_menu">
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="postjob.php">Post Job</a></li>
        <li><a href="#">Job Details</a>
            <ul>
                <li><a href="job_details.php">View Posted Jobs</a></li>
                <li><a href="messages.php">View Your Messages</a></li>
            </ul>
        </li>
        <li><a href="userprofile.php">User Profile</a></li>
        <li class="lastitem"><a href="process_payment.php">Payments</a></li>
    </ul>
</nav>

<form method="post" action="process_payment.php">
    <label for="receiver_id">Select Receiver:</label>
    <select id="receiver_id" name="receiver_id" required>
        <?php foreach ($users as $user): ?>
            <option value="<?php echo $user['id']; ?>"><?php echo $user['email']; ?></option>
        <?php endforeach; ?>
    </select>

    <label for="amount">Amount ($):</label>
    <input type="number" id="amount" name="amount" required>
    <button type="submit">Pay Now</button>
</form>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['receiver_id']) && isset($_POST['amount'])) {
        $receiver_id = $_POST['receiver_id'];
        $amount = $_POST['amount'];
    } else {
        echo "Error: Required payment information is missing.";
        exit();
    }

    try {
        // Retrieve payer's payment information
        $stmt = $pdo->prepare("SELECT p.card_number, p.expiry_date, u.email 
                               FROM payments p 
                               JOIN users u ON p.user_id = u.id 
                               WHERE u.id = ?");
        $stmt->execute([$user_id]);
        $payer = $stmt->fetch();

        if (!$payer) {
            echo "Error: Unable to retrieve payment information for payer.";
            exit();
        }

        // Retrieve receiver's payment information
        $stmt = $pdo->prepare("SELECT p.card_number, p.expiry_date, u.email 
                               FROM payments p 
                               JOIN users u ON p.user_id = u.id 
                               WHERE u.id = ?");
        $stmt->execute([$receiver_id]);
        $receiver = $stmt->fetch();

        if (!$receiver) {
            echo "Error: Unable to retrieve payment information for receiver.";
            exit();
        }

        // Simulate payment process (this is a placeholder)
        // Example: Processing payment (this is a placeholder and not a real payment gateway)
        $transaction_id = uniqid('txn_', true);
        $status = "Success"; // Assuming payment was successful

        // Save transaction to the database
        $stmt = $pdo->prepare("INSERT INTO transactions (transaction_id, payer_id, receiver_id, amount, status, created_at) 
                               VALUES (?, ?, ?, ?, ?, NOW())");
        $stmt->execute([$transaction_id, $user_id, $receiver_id, $amount, $status]);

        echo "Payment of $$amount from " . $payer['email'] . " to " . $receiver['email'] . " was successful. Transaction ID: $transaction_id.";

    } catch (PDOException $e) {
        die("Error: " . $e->getMessage());
    }
}
?>

</body>
</html>
