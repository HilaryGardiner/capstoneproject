


   /* document.addEventListener('DOMContentLoaded', function() {
        const items = document.querySelectorAll('#menu-list li a');
    
        items.forEach(item => {
            item.addEventListener('click', function() {
                // Remove 'selected' class from all items
                items.forEach(i => i.classList.remove('selected'));
    
                // Add 'selected' class to the clicked item
                this.classList.add('selected');
            });
        });
    });*/
    


    document.addEventListener('DOMContentLoaded', function() {
        const items = document.querySelectorAll('#nav_menu ul li a');
    
        items.forEach(item => {
            item.addEventListener('click', function(event) {
                // Prevent default behavior (like page reload)
                event.preventDefault();
    
                // Remove 'selected' class from all items
                items.forEach(i => i.classList.remove('selected'));
    
                // Add 'selected' class to the clicked item
                this.classList.add('selected');
            });
        });
    });
    
