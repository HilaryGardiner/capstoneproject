<?php
//Hilary Gardiner

$host = 'localhost';
$dbname = 'ihire';
$user = 'glendale';
$pass = 'phxsuns';
$charset = 'utf8mb4';

try {
    $dsn = "mysql:host=$host;dbname=$dbname;charset=$charset";
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);

    // Check if the form has been submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $fname = $_POST["fname"];
        $lname = $_POST["lname"];
        $email = $_POST["email"];
        $phone = $_POST["phone"];
        $address = $_POST["address"];
        $password = $_POST["password"];
        $confirmPassword = $_POST["confirm-password"];

        // Check if email already exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            echo "Email already in use.";
            exit();
        }

        // Check if password and confirm-password match
        if ($password !== $confirmPassword) {
            echo "Passwords do not match.";
            exit();
        }

        // Hash the password before storing it
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Prepare and execute the INSERT statement
        $stmt = $pdo->prepare("INSERT INTO users (fname, lname, email, phone, address, password) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$fname, $lname, $email, $phone, $address, $hashedPassword]);

        echo "New record created successfully";

        // Redirect to login page
        header("Location: login.php");
        exit(); // Ensure no further code execution after redirection
    }
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Account</title>
    <link rel="stylesheet" href="styles.css">

    <link rel="shortcut icon" href="images/logo3.jpg">
    <link rel="stylesheet" href="styles/main.css">
    <link rel="stylesheet" href="styles/slicknav.css">
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="js/jquery.slicknav.min.js"></script>
    <script>
        $(document).ready(function(){
            $('#nav_menu').slicknav({prependTo:"#mobile_menu"});
        });
    </script>
    <style>
        body h1{
            padding: 1em;
        }
    </style>
</head>
<body>
    <h1>Create Account</h1>
    <form id="create-account-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" onsubmit="return validateForm()">
    <label for="fname">First Name:</label>
    <input type="text" id="fname" name="fname" required><br><br>
    <label for="lname">Last Name:</label>
    <input type="text" id="lname" name="lname" required><br><br>
    <label for="email">Email:</label>
    <input type="email" id="email" name="email" required><br><br>
    <label for="phone">Phone Number:</label>
    <input type="tel" id="phone" name="phone" required><br><br>
    <label for="address">Address:</label>
    <input type="text" id="address" name="address" required><br><br>
    <label for="password">Password:</label>
    <input type="password" id="password" name="password" required><br><br>
    <label for="confirm-password">Confirm Password:</label>
    <input type="password" id="confirm-password" name="confirm-password" required><br><br>
    <button type="submit">Create Account</button>
</form>

    <script>
        // Function to validate the form
        function validateForm() {
            var fname = document.getElementById("fname").value.trim();
            var lname = document.getElementById("lname").value.trim();
            var email = document.getElementById("email").value.trim();
            var phone = document.getElementById("phone").value.trim();
            var address = document.getElementById("address").value.trim();
            var password = document.getElementById("password").value.trim();
            var confirmPassword = document.getElementById("confirm-password").value.trim();

            // Basic validation for all fields
            if (fname === "" || lname === "" || email === "" || phone === "" || address === "" || password === "" || confirmPassword === "") {
                alert("Please fill out all fields.");
                return false;
            }

            // Validation for phone number format (10 digits)
            if (!/^\d{10}$/.test(phone)) {
                alert("Please enter a valid phone number (10 digits).");
                return false;
            }

            // Additional email validation
            if (!/^\S+@\S+\.\S+$/.test(email)) {
                alert("Please enter a valid email address.");
                return false;
            }

            // Validation for mailing address (allow letters, numbers, spaces, commas, and hyphens)
            if (!/^[a-zA-Z0-9\s\-,]+$/.test(address)) {
                alert("Please enter a valid mailing address.");
                return false;
            }

            // Password confirmation check
            if (password !== confirmPassword) {
                alert("Passwords do not match.");
                return false;
            }

            // Form is valid
            return true;
        }
    </script>
</body>
</html>

