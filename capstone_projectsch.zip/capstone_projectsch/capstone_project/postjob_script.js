/*Hilary Gardiner*/

function validateForm() {
    const jobDescription = document.getElementById("job_description").value.trim();
    const jobDuration = document.getElementById("job_duration").value.trim();
    const payRate = document.getElementById("pay_rate").value.trim();

    // Validate Job Description (required)
    if (jobDescription === "") {
        alert("Please provide a job description.");
        return false;
    }

    // Validate Job Duration (required, alphanumeric)
    if (jobDuration === "") {
        alert("Please enter the job duration.");
        return false;
    }

    // Validate Pay Rate (required, numeric)
    if (payRate === "") {
        alert("Please enter the pay rate.");
        return false;
    }
    if (!/^\d+(\.\d{1,2})?$/.test(payRate)) {
        alert("Pay rate must be a valid numeric value (e.g., 100 or 99.99).");
        return false;
    }

    // All validations passed
    return true;
}
