<?php
//Hilary Gardiner

$host = 'localhost';
$dbname = 'ihire';
$user = 'glendale';
$pass = 'phxsuns';
$charset = 'utf8mb4';



// Create connection
$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}






// Close connection when done
//$conn->close();

?>
