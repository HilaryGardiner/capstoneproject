<?php
//Hilary Gardiner

session_start();

include 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Prepare SQL statement
    $sql = "SELECT id, fname, lname, password FROM users WHERE email = ?";

    // Use prepared statement to prevent SQL injection
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if query returns a row
    if ($result->num_rows == 1) {
        // Fetch user data
        $user_data = $result->fetch_assoc();

        // Verify the password
        if (password_verify($password, $user_data['password'])) {
            // Set session variables
            $_SESSION['user_id'] = $user_data['id']; // Store user ID
            $_SESSION['fname'] = $user_data['fname']; // Replace with actual column name
            $_SESSION['lname'] = $user_data['lname']; // Replace with actual column name

            // Redirect to dashboard or homepage
            header("Location: index.php");
            exit();
        } else {
            // Password does not match, redirect back to login page with error message
            echo "Invalid login credentials. Please try again.";
            header("Location: login.php");
            exit();
        }
    } else {
        // No user found with that email, redirect back to login page with error message
        echo "Invalid login credentials. Please try again.";
        header("Location: login.php");
        exit();
    }
} else {
    // Redirect to login page if accessed directly
    header("Location: login.html");
    exit();
}
?>






<!DOCTYPE html>
<html lang="en">
<head>
    
    
    <title>Login Screen</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="images/logo3.jpg">
    <link rel="stylesheet" href="styles/main.css">
    <link rel="stylesheet" href="styles/slicknav.css">
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="js/jquery.slicknav.min.js"></script>
    <script>
        $(document).ready(function(){
            $('#nav_menu').slicknav({prependTo:"#mobile_menu"});
        });
    </script>
</head>
<body>
    <header>
      <!--  <a href="#"><img src="images/logo3.jpg" alt="iHire Logo" ></a>-->
        <h3>SwiftConnections: Bridging Needs, Building Opportunities</h3>
        <h4>Welcome My Friend!</h4>
        <h5>We All Belong Here!</h5>
    </header> 
    <main>
    <div class="login-container">
        <h2>Login</h2>
        <form action="login.php" method="POST">
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Log In</button>
        </form>
        <a href="password_recovery.php">Forgot Password/Reset</a><br><br>
        <a href="create_account.php" >Create Account</a>
    </div>
</main>
</body>
</html>
