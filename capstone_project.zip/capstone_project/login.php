<?php
// Start session
session_start(); //sets up a session that will remember certain values we want stored across different PHP files
                   //It represents a visit by a user to the site; can time out if the user ignores the site for a period of time

// Include database connection
include 'db_connection.php';

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Prepare SQL statement
    $sql = "SELECT * FROM users WHERE email = ? AND password = ?";
    
    // Use prepared statement to prevent SQL injection
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $email, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if query returns a row
    if ($result->num_rows == 1) {
        // User exists, set session variables
        $_SESSION['email'] = $email;
        // Redirect to dashboard or homepage
        header("Location: index.php");
        exit();
    } else {
        // Invalid login, redirect back to login page
        header("Location: login.php");
        exit();
    }
} else {
    // Redirect to login page if accessed directly
    header("Location: login.html");
    exit();
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    
    
    <title>Login Screen</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="images/logo3.jpg">
    <link rel="stylesheet" href="styles/main.css">
    <link rel="stylesheet" href="styles/slicknav.css">
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="js/jquery.slicknav.min.js"></script>
    <script>
        $(document).ready(function(){
            $('#nav_menu').slicknav({prependTo:"#mobile_menu"});
        });
    </script>
</head>
<body>
    <header>
      <!--  <a href="#"><img src="images/logo3.jpg" alt="iHire Logo" ></a>-->
        <h3>SwiftConnections: Bridging Needs, Building Opportunities</h3>
        <h4>Welcome My Friend!</h4>
        <h5>We All Belong Here!</h5>
    </header> 
    <main>
    <div class="login-container">
        <h2>Login</h2>
        <form action="login.php" method="POST">
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Log In</button>
        </form>
        <a href="password_recovery.php">Forgot Password/Reset</a><br><br>
        <a href="create_account.php" >Create Account</a>
    </div>
</main>
</body>
</html>
