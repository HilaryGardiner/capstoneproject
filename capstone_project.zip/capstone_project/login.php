<?php
// Start session
session_start();

// Include database connection
include 'db_connection.php';

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Prepare SQL statement
    $sql = "SELECT * FROM users WHERE email = '$email' AND password = '$password'";
    
    // Execute query
    $result = mysqli_query($conn, $sql);
    
    // Check if query returns a row
    if (mysqli_num_rows($result) == 1) {
        // User exists, set session variables
        $_SESSION['email'] = $email;
        // Redirect to dashboard or homepage
        header("Location: dashboard.php");
        exit();
    } else {
        // Invalid login, redirect back to login page
        header("Location: login.html");
        exit();
    }
} else {
    // Redirect to login page if accessed directly
    header("Location: login.html");
    exit();
}
?>
