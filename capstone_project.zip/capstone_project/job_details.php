<?php
session_start();
include 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $job_description = $_POST["job_description"];
    $job_duration = $_POST["job_duration"];
    $pay_rate = $_POST["pay_rate"];

    // Check if the table 'postjob' exists
    $sql_check_table = "SELECT 1 FROM postjobtable LIMIT 1";
    $result = $conn->query($sql_check_table);

    if ($result) {
        // Table exists, retrieve data
        $sql_retrieve_data = "SELECT * FROM postjobtable";
        $stmt = $conn->prepare($sql_retrieve_data);
        $stmt->execute();
        $result_set = $stmt->get_result();

        if ($result_set->num_rows > 0) {
            echo "Data retrieved from 'postjobtable':<br>";
            while ($row = $result_set->fetch_assoc()) {
                echo "Job ID: " . $row["id"] . ", Description: " . $row["job_description"] . ", Duration: " . $row["job_duration"] . ", Pay Rate: " . $row["pay_rate"] . "<br>";
            }
        } else {
            echo "No data found in 'postjobtable'.";
        }
    } else {
        echo "Table 'postjobtable' does not exist.";
    }

    // Close connection
    $stmt->close();
    $conn->close();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
	<title>Job Details</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial scale=1">
	<link rel="shortcut icon" href="images/logo3.jpg">
	<link rel="stylesheet" href="styles/main.css">
	<link rel="stylesheet" href="styles/slicknav.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="js/jquery.slicknav.min.js"></script>
    <script>
        $(document).ready(function(){
            $('#nav_menu').slicknav({prependTo:"#mobile_menu"});
        });
    </script>
</head>

<body>
    <header>
        <a href="index.html"><img src="images/logo3.jpg" alt="iHire Logo" ></a>
        <h3>SwiftConnections: Bridging Needs, Building Opportunities</h3>
        <h4>Welcome My Friend!</h4>
        
    </header>
    <nav id="mobile_menu"></nav>
    <nav id="nav_menu">
        <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="postjob.html">Post Job</a>
                
            </li>
            <li><a href="jobdetails.html">Job Details</a>
                <ul>
                    <li><a href="jobdetails.html">Form</a>
                    </li>
                </ul>
            </li>
            <li><a href="userprofile.html">User Profile</a>
                <ul>
                    <li><a href="imagemaps/imagemaps.html">Map</a>
                        <ul>
                            <li><a href="https://www.tsa.gov/contact/lost-and-found" target="_blank" rel="noopener noreferrer">TSA lost and found</a></li>
                            <li><a href="https://disneyworld.disney.go.com/guest-services/lost-and-found/" target="_blank" rel="noopener noreferrer">Disney world lost and found</a></li>
                        </ul>
                    </li>  
                </ul>
            </li>
            <li class="lastitem"><a href="settings.html">Settings</a>
                <ul>
                    <li><a href="twotiernav.html">Finding Lost Items</a></li>
                    <li><a href="twotiernav.html">Preventing Loss</a></li>
                </ul>
            </li> 
            
            
            
        </ul>
    </nav>
		
   <!-- <h1>Job Details</h1>
    <div class="job-details">
        <h2>Job Title</h2>
        <p>Description: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla rutrum purus a nunc efficitur, et cursus ipsum bibendum. In hac habitasse platea dictumst.</p>
        <p>Duration: 2 hours</p>
        <p>Pay Rate: $20</p>-->

        <h1>Job Details</h1>
        <h3>This page is under construction</h3>

        
        <button id="apply-button">Apply</button>
    </div>

    <script src="script.js"></script>
    <footer>
        <p>You are not alone!</p>
    </footer>

</body>
</html>
