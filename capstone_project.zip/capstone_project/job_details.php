<?php
// Assume PHP logic to retrieve job details from a database and determine whether contact exchange is allowed
$allowContactExchange = true; // Change this based on your logic

// Sample job details
$jobTitle = "Sample Job";
$jobDescription = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla rutrum purus a nunc efficitur, et cursus ipsum bibendum. In hac habitasse platea dictumst.";
$jobDuration = "2 hours";
$payRate = "$20";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $jobTitle; ?></title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1><?php echo $jobTitle; ?></h1>
    <div class="job-details">
        <h2>Job Details</h2>
        <p>Description: <?php echo $jobDescription; ?></p>
        <p>Duration: <?php echo $jobDuration; ?></p>
        <p>Pay Rate: <?php echo $payRate; ?></p>
        <?php 
            if ($allowContactExchange) {
                echo '<button id="contact-button">Contact</button>';
            }
        ?>
        <button id="apply-button">Apply</button>
    </div>

    <script src="script.js"></script>
</body>
</html>
