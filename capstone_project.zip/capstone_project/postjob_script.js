function validateForm() {
    var jobDuration = document.getElementById("job_duration").value.trim();
    var payRate = document.getElementById("pay_rate").value.trim();

    // Validate job duration
    if (!/^(\d+(\.\d+)?\s*(h(ou)?rs?|m(in(ute)?s?)?))?$/i.test(jobDuration)) {
        alert("Please enter a valid job duration. Example: '2 hours', '30 minutes', '1.5 hours'");
        return false;
    }

    // Validate pay rate
    if (!/^\$?\d+(\.\d+)?$/.test(payRate)) {
        alert("Please enter a valid pay rate. Example: '$20', '15.5'");
        return false;
    }

    return true;
}
