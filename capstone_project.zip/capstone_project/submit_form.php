<?php
// Database connection details
$servername = "localhost"; // Change this to your MySQL server address
$username = "Glendale"; // Change this to your MySQL username
$password = "PhxSuns24!"; // Change this to your MySQL password
$dbname = "ihire"; // Change this to the name of your MySQL database

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$fname = $_POST["fname"];
$lname = $_POST["lname"];
$email = $_POST["email"];
$phone = $_POST["phone"];
$address = $_POST["address"];
$password = $_POST["password"];

// SQL INSERT statement
$sql = "INSERT INTO users (fname, lname, email, phone, address, password) VALUES ('$fname', '$lname', '$email', '$phone', '$address', '$password')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close connection
$conn->close();
?>
