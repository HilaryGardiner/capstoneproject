<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $job_description = $_POST["job_description"];
    $job_duration = $_POST["job_duration"];
    $pay_rate = $_POST["pay_rate"];
    $contact_exchange = isset($_POST["contact_exchange"]) ? "Yes" : "No";

    // Process the data (You can perform further actions here like saving to a database)
    
    // Redirect to a thank you page
    header("Location: thank_you.php");
    exit;
}
?>