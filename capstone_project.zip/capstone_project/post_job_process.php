<?php
// Start session
session_start();

// Include database connection
include 'db_connection.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $job_description = $_POST["job_description"];
    $job_duration = $_POST["job_duration"];
    $pay_rate = $_POST["pay_rate"];

    // Check if the table 'postjob' exists
    $sql_check_table = "SELECT 1 FROM postjob LIMIT 1";
    $result = $conn->query($sql_check_table);

    if (!$result) {
        // Table does not exist, create it
        $sql_create_table = "CREATE TABLE postjob (
            id INT AUTO_INCREMENT PRIMARY KEY,
            job_description VARCHAR(255) NOT NULL,
            job_duration INT NOT NULL,
            pay_rate DECIMAL(10, 2) NOT NULL
        )";

        if ($conn->query($sql_create_table)) {
            // Table created successfully, insert data
            $sql_insert_data = "INSERT INTO postjob (job_description, job_duration, pay_rate)
                               VALUES ('$job_description', $job_duration, $pay_rate)";
            if ($conn->query($sql_insert_data)) {
                echo "New record created successfully";
            } else {
                echo "Error inserting data: " . $conn->error;
            }
        } else {
            echo "Error creating table: " . $conn->error;
        }
    } else {
        // Table already exists, handle accordingly
        echo "Table 'postjob' already exists";
    }

    // Close connection
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
    <title>Post Job</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="images/logo3.jpg">
    <link rel="stylesheet" href="styles/main.css">
    <link rel="stylesheet" href="styles/slicknav.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="js/jquery.slicknav.min.js"></script>

	
    <script>
        $(document).ready(function(){
            $('#nav_menu').slicknav({prependTo:"#mobile_menu"});
        });
    </script>
   
</head>

<body>
	<header>
        <a href="index.html"><img src="images/logo3.jpg" alt="iHire Logo" ></a>
        <h3>SwiftConnections: Bridging Needs, Building Opportunities</h3>
        <h4>Welcome My Friend!</h4>
        
    </header>
    <nav id="mobile_menu"></nav>
    <nav id="nav_menu">
        <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="postjob.html">Post Job</a>
                
            </li>
            <li><a href="jobdetails.html">Job Details</a>
                <ul>
                    <li><a href="jobdetails.html">Form</a>
                    </li>
                </ul>
            </li>
            <li><a href="userprofile.html">User Profile</a>
                <ul>
                    <li><a href="imagemaps/imagemaps.html">Map</a>
                        <ul>
                            <li><a href="https://www.tsa.gov/contact/lost-and-found" target="_blank" rel="noopener noreferrer">TSA lost and found</a></li>
                            <li><a href="https://disneyworld.disney.go.com/guest-services/lost-and-found/" target="_blank" rel="noopener noreferrer">Disney world lost and found</a></li>
                        </ul>
                    </li>  
                </ul>
            </li>
            <li class="lastitem"><a href="settings.html">Settings</a>
                <ul>
                    <li><a href="twotiernav.html">Finding Lost Items</a></li>
                    <li><a href="twotiernav.html">Preventing Loss</a></li>
                </ul>
            </li> 
            
            
            
        </ul>
    </nav>
	
    <form action="post_job_process.php" method="POST" onsubmit="return validateForm()">
        <label for="job_description">Job Description:</label>
        <textarea id="job_description" name="job_description" required></textarea><br><br>
        
        <label for="job_duration">Job Duration:</label>
        <input type="text" id="job_duration" name="job_duration" required><br><br>
        
        <label for="pay_rate">Pay Rate:</label>
        <input type="text" id="pay_rate" name="pay_rate" required><br><br>
        
        <input type="checkbox" id="contact_exchange" name="contact_exchange">
        <label for="contact_exchange">Allow Contact Information Exchange</label><br><br>
        
        <button type="submit">Post Job</button>
    </form>

    <script src="postjob_script.js"></script>
	

</body>

</html>
