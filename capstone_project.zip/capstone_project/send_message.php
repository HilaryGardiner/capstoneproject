<?php
session_start();

include 'db_connection.php';

// Define a simple sanitize_input function (you can enhance this as needed)
function sanitize_input($input) {
    return htmlspecialchars(trim($input));
}

// Function to get user's messages
function get_messages($user_id, $conn) {
    $sql = "SELECT * FROM messages WHERE sender_id = ? OR recipient_id = ? ORDER BY timestamp DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $user_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

// Send message
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Assuming you have user authentication and have stored user ID in session
    if (isset($_SESSION['user_id'])) {
        $sender_id = $_SESSION['user_id'];
        $recipient_id = $_POST['recipient_id'];
        $message = sanitize_input($_POST['message']);

        // Insert the message into the database
        $sql_insert_message = "INSERT INTO messages (sender_id, recipient_id, message) VALUES (?, ?, ?)";

        try {
            $stmt = $conn->prepare($sql_insert_message);
            if (!$stmt) {
                throw new Exception("Error preparing statement: " . $conn->error);
            }

            $stmt->bind_param("iis", $sender_id, $recipient_id, $message);
            $stmt->execute();
            echo "Message sent successfully.";
        } catch (Exception $e) {
            echo "Error sending message: " . $e->getMessage();
        }
    } else {
        echo "Error: User ID not set in session.";
    }
}

// Get messages for the logged-in user
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $user_messages = get_messages($user_id, $conn);
    
    // Display messages
    echo "<h2>Your Messages</h2>";
    if (!empty($user_messages)) {
        echo "<ul>";
        foreach ($user_messages as $message) {
            $sender_id = $message['sender_id'];
            $recipient_id = $message['recipient_id'];
            $message_content = $message['message'];
            $timestamp = $message['timestamp'];
            $message_sender = ($sender_id == $user_id) ? "You" : "Sender"; // Replace "Sender" with actual sender name
            echo "<li><strong>$message_sender:</strong> $message_content <span>($timestamp)</span></li>";
        }
        echo "</ul>";
    } else {
        echo "No messages found.";
    }
} else {
    echo "Error: User not logged in.";
}

// Close connection
$conn->close();
?>

