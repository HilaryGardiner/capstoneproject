<?php // Example 05: signup.php
  require_once 'header.php'; //includes the contents of the file header.php 
  //into the current PHP script. require_once function is used to ensure that 
  //the file is included only once to preventing issues

// Script for checking username availability
echo <<<_END
  <script>
    function checkUser(user)
    {
      // Check if the input field is empty
      if (user.value == '')
      {
        // If empty, clear the '#used' element
        $('#used').html('&nbsp;')
        return
      }
      // Make an AJAX POST request to checkuser.php
      $.post
      (
        'checkuser.php',  // PHP script to handle the request
        { user : user.value }, // Data to be sent to the server
        function(data) // Callback function to handle the response
        {
          // Update the '#used' element with the response
          $('#used').html(data)
        }
      )
    }
  </script>  
_END;
    // Initialize variables
  $error = $user = $pass = "";
  // If the user is already logged in, log them out
  if (isset($_SESSION['user'])) destroySession();

  // If form is submitted  
  if (isset($_POST['fname'])) // Change 'user' to 'fname' to match HTML form field name
  {
    // Sanitize input data
    $fname = sanitizeString($_POST['fname']); // Change 'user' to 'fname' to match HTML form field name
    $lname = sanitizeString($_POST['lname']); // Change 'pass' to 'lname' to match HTML form field name
    $email = sanitizeString($_POST['email']); // Add sanitization for email
    $phone = sanitizeString($_POST['phone']); // Add sanitization for phone
    $address = sanitizeString($_POST['address']); // Add sanitization for address
    $password = sanitizeString($_POST['password']); // Add sanitization for password
    $confirm_password = sanitizeString($_POST['confirm-password']); // Add sanitization for confirm-password

    // Check if fields are empty
    if ($fname == "" || $lname == "" || $email == "" || $phone == "" || $address == "" || $password == "" || $confirm_password == "")
      $error = 'Not all fields were entered<br><br>';
    else
    {
      // Check if the username already exists in the database
      $result = queryMysql("SELECT * FROM members WHERE user='$fname'");

      if ($result->rowCount())
        $error = 'That username already exists<br><br>';
      else
      {
        // If username doesn't exist, insert new user into the database
        queryMysql("INSERT INTO members (user, pass) VALUES('$fname', '$password')"); // Change 'user' to 'fname' to match HTML form field name
        die('<h4>Account created</h4>Please Log in.</div></body></html>');
      }
    }
  }

echo <<<_END
      <form id="create-account-form" method='post' action='signup.php?r=$randstr'>$error <!-- Add form id and remove action attribute to post to the same page -->
      <div data-role='fieldcontain'>
        <label></label>
        Please enter your details to sign up
      </div>
      <div data-role='fieldcontain'>
        <label>First Name:</label>
        <input type='text' id='fname' maxlength='16' name='fname' value='' onBlur='checkUser(this)'> <!-- Add onBlur event to call checkUser function -->
        <label></label><div id='used'>&nbsp;</div><!-- Display availability message -->
      </div>
      <div data-role='fieldcontain'>
        <label>Last Name:</label>
        <input type='text' id='lname' maxlength='16' name='lname' value=''><br><br>
      </div>
      <div data-role='fieldcontain'>
        <label>Email:</label>
        <input type='email' id='email' name='email' value=''><br><br>
      </div>
      <div data-role='fieldcontain'>
        <label>Phone Number:</label>
        <input type='tel' id='phone' name='phone' value=''><br><br>
      </div>
      <div data-role='fieldcontain'>
        <label>Address:</label>
        <input type='text' id='address' name='address' value=''><br><br>
      </div>
      <div data-role='fieldcontain'>
        <label>Password:</label>
        <input type='password' id='password' name='password' value=''><br><br>
      </div>
      <div data-role='fieldcontain'>
        <label>Confirm Password:</label>
        <input type='password' id='confirm-password' name='confirm-password' value=''><br><br>
      </div>
      <div data-role='fieldcontain'>
        <label></label>
        <button type='submit'>Create Account</button> <!-- Change input type to button -->
      </div>
    </form>
  </body>
</html>
_END;
?>
