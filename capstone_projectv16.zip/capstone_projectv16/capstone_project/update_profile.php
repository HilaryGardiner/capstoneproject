<?php
session_start();

$host = 'localhost';
$dbname = 'your_database';
$user = 'your_user';
$pass = 'your_password';
$charset = 'utf8mb4';

try {
    $dsn = "mysql:host=$host;dbname=$dbname;charset=$charset";
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);

    // Assuming the user ID is stored in the session
    $user_id = $_SESSION['user_id'];

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Handle profile picture upload
        if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] == UPLOAD_ERR_OK) {
            $uploadDir = 'uploads/';
            $profilePictureName = basename($_FILES['profile_picture']['name']);
            $uploadFile = $uploadDir . $profilePictureName;

            // Move the uploaded file to the destination directory
            if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $uploadFile)) {
                $profilePicture = $uploadFile;
            } else {
                echo "Failed to upload profile picture.";
            }
        }

        $fname = $_POST['fname'];
        $lname = $_POST['lname'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $address = $_POST['address'];
        $password = $_POST['password'];

        // Update user profile information
        $stmt = $pdo->prepare("UPDATE users SET fname = ?, lname = ?, email = ?, phone = ?, address = ?, password = ?, profile_picture = ? WHERE id = ?");
        $stmt->execute([$fname, $lname, $email, $phone, $address, password_hash($password, PASSWORD_DEFAULT), $profilePicture, $user_id]);

        // Update payment information
        $card_number = $_POST['card_number'];
        $cardholder_name = $_POST['cardholder_name'];
        $expiry_date = $_POST['expiry_date'];
        $cvv = $_POST['cvv'];

        // Check if payment record exists for the user
        $stmt = $pdo->prepare("SELECT id FROM payments WHERE user_id = ?");
        $stmt->execute([$user_id]);
        $payment = $stmt->fetch();

        if ($payment) {
            // Update existing payment record
            $stmt = $pdo->prepare("UPDATE payments SET card_number = ?, cardholder_name = ?, expiry_date = ?, cvv = ? WHERE user_id = ?");
            $stmt->execute([$card_number, $cardholder_name, $expiry_date, $cvv, $user_id]);
        } else {
            // Insert new payment record
            $stmt = $pdo->prepare("INSERT INTO payments (user_id, card_number, cardholder_name, expiry_date, cvv) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$user_id, $card_number, $cardholder_name, $expiry_date, $cvv]);
        }

        echo "Profile updated successfully!";
    }
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>
