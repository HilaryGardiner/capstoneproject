


<!DOCTYPE html>
<html lang="en">
<head>
	<title>Job Details</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial scale=1">
	<link rel="shortcut icon" href="images/logo3.jpg">
	<link rel="stylesheet" href="styles/main.css">
	<link rel="stylesheet" href="styles/slicknav.css">
    <link rel="stylesheet" href="table_form.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="js/jquery.slicknav.min.js"></script>
    <script>
        $(document).ready(function(){
            $('#nav_menu').slicknav({prependTo:"#mobile_menu"});
        });
    </script>
</head>

<body style="margin: 15px auto;">

    <header>
        <a href="index.php"><img src="images/logo3.jpg" alt="iHire Logo" ></a>
        <h3>SwiftConnections: Bridging Needs, Building Opportunities</h3>
        <h4>Welcome My Friend!</h4>
        
    </header>
    <nav id="mobile_menu"></nav>
    <nav id="nav_menu">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="postjob.php">Post Job</a>
                
            </li>
            <li><a href="#">Job Details</a>
                <ul>
                    <li><a href="job_details.php">View Posted Jobs</a> </li>
                    <li><a href="messages.php">View Your Messages</a> </li>
                </ul>
            </li>
            <li><a href="userprofile.php">User Profile</a>
                <!--<ul>
                    <li><a href="imagemaps/imagemaps.html">Map</a>
                        <ul>
                            <li><a href="https://www.tsa.gov/contact/lost-and-found" target="_blank" rel="noopener noreferrer">TSA lost and found</a></li>
                            <li><a href="https://disneyworld.disney.go.com/guest-services/lost-and-found/" target="_blank" rel="noopener noreferrer">Disney world lost and found</a></li>
                        </ul>
                    </li>  
                </ul>-->
            </li>
            <li class="lastitem"><a href="settings.html">Settings</a>
                <ul>
                    <li><a href="twotiernav.html">Finding Lost Items</a></li>
                    <li><a href="twotiernav.html">Preventing Loss</a></li>
                </ul>
            </li> 
            
            
            
        </ul>
    </nav>
		
   
    
<?php
session_start();
include 'db_connection.php';

function sanitize_input($data) {
    return htmlspecialchars(trim($data));
}

if (!isset($_SESSION['user_id'])) {
    die("<div>You must be logged in to view job details.</div></body></html>");
}

$user_id = $_SESSION['user_id'];

$city = isset($_POST['city']) ? sanitize_input($_POST['city']) : '';
$state = isset($_POST['state']) ? sanitize_input($_POST['state']) : '';

$sql_check_table = "SELECT 1 FROM postjobtable LIMIT 1";
$result = $conn->query($sql_check_table);

if ($result) {
    $sql_retrieve_data = "SELECT * FROM postjobtable";
    if ($city !== '' && $state !== '') {
        $sql_retrieve_data .= " WHERE city = ? AND state = ?";
    }
    
    $stmt = $conn->prepare($sql_retrieve_data);

    if ($city !== '' && $state !== '') {
        $stmt->bind_param("ss", $city, $state);
    }

    $stmt->execute();
    $result = $stmt->get_result();

    echo "<html><body>";
    echo "<form method='post' action='job_details.php'>
            <label for='city'>City:</label>
            <input type='text' id='city' name='city' value='$city'><br>
            <label for='state'>State:</label>
            <input type='text' id='state' name='state' value='$state'><br>
            <button type='submit'>Search</button>
          </form>";
    echo "<table class='job-table' border='1'>";
    echo "<tr><th>Job ID</th><th>Description</th><th>Duration</th><th>Pay Rate</th><th>Name</th><th>City</th><th>State</th><th>Posted At</th><th>Messages</th></tr>";

    while ($row = $result->fetch_assoc()) {
        $job_id = $row['id'];
        $description = $row['job_description'];
        $duration = $row['job_duration'];
        $rate = $row['pay_rate'];
        $first_name = $row['first_name'];
        $last_name = $row['last_name'];
        $city = $row['city'];
        $state = $row['state'];
        $posted_at = $row['posted_at'];
        $poster_id = $row['user_id']; // Assuming this is the job poster's user ID

        echo "<tr><td>$job_id</td><td>$description</td><td>$duration</td><td>$rate</td><td>$first_name $last_name</td><td>$city</td><td>$state</td><td>$posted_at</td><td>";

        echo "<form method='post' action='messages.php?job_id=$job_id&receiver_id=$poster_id'>
              <textarea name='message' rows='2' cols='30' placeholder='Type your message'></textarea><br>
              <input type='submit' value='Send'>
              </form>";

        echo "</td></tr>";
    }
    echo "</table></body></html>";
} else {
    echo "Error: Table 'postjobtable' does not exist.";
}

$conn->close();
?>


    <br><br>     

        
        <button id="apply-button">Apply</button>
    

    <script src="script.js"></script>
    <footer>
        <p>You are not alone!</p>
    </footer>

</body>
</html>
