


<!DOCTYPE html>
<html lang="en">
<head>
	<title>Job Details</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial scale=1">
	<link rel="shortcut icon" href="images/logo3.jpg">
	<link rel="stylesheet" href="styles/main.css">
	<link rel="stylesheet" href="styles/slicknav.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="js/jquery.slicknav.min.js"></script>
    <script>
        $(document).ready(function(){
            $('#nav_menu').slicknav({prependTo:"#mobile_menu"});
        });
    </script>
</head>

<body>
    <header>
        <a href="index.php"><img src="images/logo3.jpg" alt="iHire Logo" ></a>
        <h3>SwiftConnections: Bridging Needs, Building Opportunities</h3>
        <h4>Welcome My Friend!</h4>
        
    </header>
    <nav id="mobile_menu"></nav>
    <nav id="nav_menu">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="postjob.php">Post Job</a>
                
            </li>
            <li><a href="job_details.php">Job Details</a>
                <ul>
                    <li><a href="send_message.php">View Your Messages</a>
                    </li>
                </ul>
            </li>
            <li><a href="userprofile.html">User Profile</a>
                <ul>
                    <li><a href="imagemaps/imagemaps.html">Map</a>
                        <ul>
                            <li><a href="https://www.tsa.gov/contact/lost-and-found" target="_blank" rel="noopener noreferrer">TSA lost and found</a></li>
                            <li><a href="https://disneyworld.disney.go.com/guest-services/lost-and-found/" target="_blank" rel="noopener noreferrer">Disney world lost and found</a></li>
                        </ul>
                    </li>  
                </ul>
            </li>
            <li class="lastitem"><a href="settings.html">Settings</a>
                <ul>
                    <li><a href="twotiernav.html">Finding Lost Items</a></li>
                    <li><a href="twotiernav.html">Preventing Loss</a></li>
                </ul>
            </li> 
            
            
            
        </ul>
    </nav>
		
   
    <?php
// Start session
session_start();

// Include database connection
include 'db_connection.php';

// Function to sanitize input data
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Check if the table 'postjobtable' exists
$sql_check_table = "SELECT 1 FROM postjobtable LIMIT 1";
$result = $conn->query($sql_check_table);

if ($result) {
    // Table exists, retrieve data
    $sql_retrieve_data = "SELECT * FROM postjobtable";

    try {
        $stmt = $conn->prepare($sql_retrieve_data);
        $stmt->execute();
        $result = $stmt->get_result();

        // Print the data in an HTML table
        echo "<html><body><table border='1'>";
        echo "<tr><th>Job ID</th><th>Description</th><th>Duration</th><th>Pay Rate</th><th>Name</th><th>Message</th></tr>";

        while ($row = $result->fetch_assoc()) {
            $job_id = $row['id'];
            $description = $row['job_description'];
            $duration = $row['job_duration'];
            $rate = $row['pay_rate'];
            $first_name = $row['first_name'];
            $last_name = $row['last_name'];

            echo "<tr><td>$job_id</td><td>$description</td><td>$duration</td><td>$rate</td><td>$first_name $last_name</td><td>";
            // Form for sending messages
            echo "<form method='post' action='send_message.php'>";
            echo "<input type='hidden' name='recipient_id' value='$job_id'>";
            // Get the user's name from session
            $user_name = $_SESSION['fname'] . " " . $_SESSION['lname'];
            echo "<input type='hidden' name='thread_id' value='$user_name'>"; // Use the user's name as thread ID
            echo "<textarea name='message' rows='2' cols='30' placeholder='Type your message'></textarea><br>";
            echo "<input type='submit' value='Send'>";
            echo "</form>";
            echo "</td></tr>";
        }

        echo "</table></body></html>";
    } catch (Exception $e) {
        echo "Error retrieving data: " . $e->getMessage();
    }
} else {
    echo "Error: Table 'postjobtable' does not exist.";
}

// Close connection
$conn->close();
?>

    


    <br><br>     

        
        <button id="apply-button">Apply</button>
    

    <script src="script.js"></script>
    <footer>
        <p>You are not alone!</p>
    </footer>

</body>
</html>
