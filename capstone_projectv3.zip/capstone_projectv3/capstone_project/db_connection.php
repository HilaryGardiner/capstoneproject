<?php
// Database configuration
/*$servername = "localhost";
$username = "username";
$password = "password";
$database = "database";*/

$host = 'localhost';
$dbname = 'ihire';
$user = 'glendale';
$pass = 'phxsuns';
$charset = 'utf8mb4';

// Create connection
//$conn = new mysqli($servername, $username, $password, $database);
/*$conn = new mysqli($host, $dbname, $user, $pass);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}*/

// Create connection
$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Rest of your code (e.g., executing queries) goes here




// Close connection when done
//$conn->close();

?>
