


<!DOCTYPE html>
<html lang="en">
<head>
	<title>Job Details</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial scale=1">
	<link rel="shortcut icon" href="images/logo3.jpg">
	<link rel="stylesheet" href="styles/main.css">
	<link rel="stylesheet" href="styles/slicknav.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="js/jquery.slicknav.min.js"></script>
    <script>
        $(document).ready(function(){
            $('#nav_menu').slicknav({prependTo:"#mobile_menu"});
        });
    </script>
</head>

<body>
    <header>
        <a href="index.php"><img src="images/logo3.jpg" alt="iHire Logo" ></a>
        <h3>SwiftConnections: Bridging Needs, Building Opportunities</h3>
        <h4>Welcome My Friend!</h4>
        
    </header>
    <nav id="mobile_menu"></nav>
    <nav id="nav_menu">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="postjob.php">Post Job</a>
                
            </li>
            <li><a href="job_details.php">Job Details</a>
                <ul>
                    <li><a href="send_message.php">View Your Messages</a>
                    </li>
                </ul>
            </li>
            <li><a href="userprofile.html">User Profile</a>
                <ul>
                    <li><a href="imagemaps/imagemaps.html">Map</a>
                        <ul>
                            <li><a href="https://www.tsa.gov/contact/lost-and-found" target="_blank" rel="noopener noreferrer">TSA lost and found</a></li>
                            <li><a href="https://disneyworld.disney.go.com/guest-services/lost-and-found/" target="_blank" rel="noopener noreferrer">Disney world lost and found</a></li>
                        </ul>
                    </li>  
                </ul>
            </li>
            <li class="lastitem"><a href="settings.html">Settings</a>
                <ul>
                    <li><a href="twotiernav.html">Finding Lost Items</a></li>
                    <li><a href="twotiernav.html">Preventing Loss</a></li>
                </ul>
            </li> 
            
            
            
        </ul>
    </nav>

    <?php
session_start();
include 'db_connection.php'; // Include your database connection file

// Define a simple sanitize_input function (you can enhance this as needed)
function sanitize_input($input) {
    return htmlspecialchars(trim($input));
}

// Function to get user's messages grouped by thread
function get_messages_by_thread($user_id, $conn) {
    $sql = "SELECT * FROM messages WHERE sender_id = ? OR recipient_id = ? ORDER BY thread_id, timestamp ASC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $user_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $threads = [];
    while ($row = $result->fetch_assoc()) {
        $thread_id = $row['thread_id'];
        $threads[$thread_id][] = $row;
    }
    return $threads;
}

// Send message
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_SESSION['user_id'])) {
        $sender_id = $_SESSION['user_id'];
        $recipient_id = $_POST['recipient_id'];
        $message = sanitize_input($_POST['message']);
        // Get the user's name from session
        $sender_name = $_SESSION['fname'] . " " . $_SESSION['lname'];
        // Use the user's name as thread ID
        $thread_id = $sender_name;
        
        // Insert the message into the database with the appropriate thread ID
        $sql_insert_message = "INSERT INTO messages (sender_id, recipient_id, message, thread_id) VALUES (?, ?, ?, ?)";
        try {
            $stmt = $conn->prepare($sql_insert_message);
            if (!$stmt) {
                throw new Exception("Error preparing statement: " . $conn->error);
            }
            $stmt->bind_param("iiss", $sender_id, $recipient_id, $message, $thread_id);
            $stmt->execute();
            echo "Message sent successfully.";
        } catch (Exception $e) {
            echo "Error sending message: " . $e->getMessage();
        }
    } else {
        echo "Error: User ID not set in session.";
    }
}

// Get messages for the logged-in user
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $user_threads = get_messages_by_thread($user_id, $conn);
    
    // Display messages grouped by thread
    echo "<h2>Your Messages</h2>";
    foreach ($user_threads as $thread_id => $thread_messages) {
        echo "<hr><h3>Message Thread (Thread ID: $thread_id)</h3>";
        foreach ($thread_messages as $message) {
            echo "<p>{$message['message']}</p>";
        }
        
        // Add a form for responding to the thread
        echo '<form method="post" action="">';
        echo '<input type="hidden" name="recipient_id" value="' . $message['recipient_id'] . '">';

        // Get the user's name from session
        $sender_name = $_SESSION['fname'] . " " . $_SESSION['lname'];
        // Use the user's name as thread ID
        echo '<input type="hidden" name="thread_id" value="' . $sender_name . '">'; // Include thread ID
        echo '<textarea name="message" placeholder="Type your response here"></textarea>';
        echo '<input type="submit" value="Send Response">';
        echo '</form>';
    }
}
?>






<br><br>     

        
        <button id="apply-button">Apply</button>
    

    <script src="script.js"></script>
    <footer>
        <p>You are not alone!</p>
    </footer>

</body>
</html>