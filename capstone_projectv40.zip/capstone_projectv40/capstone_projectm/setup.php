<?php

session_start();
include 'db_connection.php';

// Function to sanitize user input
function sanitize_input($data) {
    return htmlspecialchars(trim($data));
}

try {
    // Set up the DSN (Data Source Name)
    $dsn = "mysql:host=$host;dbname=$dbname;charset=$charset";

    // Create a new PDO instance
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,  // Set the PDO error mode to exception
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, // Fetch associative arrays by default
        PDO::ATTR_EMULATE_PREPARES => false,  // Turn off emulation mode for prepared statements
    ]);

    // SQL statement to create the users table
    $usersTableSql = "
    CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY, -- Unique identifier for each user
    fname VARCHAR(50) NOT NULL,         -- First name of the user
    lname VARCHAR(50) NOT NULL,         -- Last name of the user
    email VARCHAR(100) NOT NULL UNIQUE, -- Email address (must be unique)
    phone VARCHAR(20),                  -- Phone number (optional)
    address TEXT,                       -- Address of the user (optional, allows longer text)
    password VARCHAR(255) NOT NULL,     -- Hashed password of the user
    profile_picture VARCHAR(255),       -- Path to the user's profile picture (optional)
    background_check_completed BOOLEAN DEFAULT FALSE, -- Background check status
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, -- Timestamp when the user was created
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP -- Timestamp of the last update
    );
    ";

    // SQL statement to create the admins table
    $adminsTableSql = "
    CREATE TABLE IF NOT EXISTS admins (
        id INT AUTO_INCREMENT PRIMARY KEY, -- Unique identifier for each admin
        username VARCHAR(255) NOT NULL UNIQUE, -- Unique username for the admin
        password VARCHAR(255) NOT NULL, -- Hashed password
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP -- Timestamp of account creation
    );
    ";

    // SQL statement to create the payments table
    $paymentsTableSql = "
        CREATE TABLE IF NOT EXISTS payments (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            card_number VARCHAR(16) NOT NULL,
            cardholder_name VARCHAR(255) NOT NULL,
            expiry_date DATE NOT NULL,
            cvv VARCHAR(4) NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        );
    ";

    // SQL statement to create the password_resets table
    $passwordResetsTableSql = "
        CREATE TABLE IF NOT EXISTS password_resets (
            id INT AUTO_INCREMENT PRIMARY KEY,
            email VARCHAR(255) NOT NULL,
            token VARCHAR(255) NOT NULL,
            expires_at DATETIME NOT NULL
        );
    ";

    // SQL statement to create the transactions table
    $transactionsTableSql = "
        CREATE TABLE IF NOT EXISTS transactions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            transaction_id VARCHAR(255) NOT NULL,
            payer_id INT NOT NULL,
            receiver_id INT NOT NULL,
            amount DECIMAL(10, 2) NOT NULL,
            status VARCHAR(50) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (payer_id) REFERENCES users(id),
            FOREIGN KEY (receiver_id) REFERENCES users(id)
        );
    ";

    // SQL statement to create the notifications table
    $notificationsTableSql = "
        CREATE TABLE IF NOT EXISTS notifications (
             id INT AUTO_INCREMENT PRIMARY KEY,
             user_id INT NOT NULL,
             message TEXT NOT NULL,
             is_read BOOLEAN DEFAULT 0,
             created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
             FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        );
    ";

    // Execute the SQL statements
    $pdo->exec($usersTableSql);
    echo "Table 'users' created successfully.<br>";

    $pdo->exec($adminsTableSql);
    echo "Table 'admins' created successfully.<br>";

    $pdo->exec($paymentsTableSql);
    echo "Table 'payments' created successfully.<br>";

    $pdo->exec($passwordResetsTableSql);
    echo "Table 'password_resets' created successfully.<br>";

    $pdo->exec($transactionsTableSql);
    echo "Table 'transactions' created successfully.<br>";

    $pdo->exec($notificationsTableSql);
    echo "Table 'notifications' created successfully.<br>";

} catch (PDOException $e) {
    // Handle any errors that occur during the connection or table creation
    echo "Error: " . $e->getMessage();
}
?>
