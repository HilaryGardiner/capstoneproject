<?php
session_start();
include 'db_connection.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirect to login page if user is not logged in
    exit();
}

// Function to check if 'responses' table exists and create it if not
function create_responses_table($conn) {
    $sql_check_table = "SHOW TABLES LIKE 'responses'";
    $result = $conn->query($sql_check_table);
    if ($result->num_rows == 0) {
        $sql_create_table = "CREATE TABLE responses (
                                id INT(11) AUTO_INCREMENT PRIMARY KEY,
                                message_id INT(11) NOT NULL,
                                sender_id INT(11) NOT NULL,
                                response TEXT NOT NULL,
                                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                            )";
        if ($conn->query($sql_create_table) === TRUE) {
            echo "Table 'responses' created successfully.<br>";
        } else {
            echo "Error creating table: " . $conn->error . "<br>";
        }
    }
}

// Call function to create 'responses' table if it doesn't exist
create_responses_table($conn);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Assuming you have user authentication and have stored user ID in session
    if (isset($_SESSION['user_id'])) {
        $sender_id = $_SESSION['user_id'];
        $message_id = $_POST['message_id'];
        $message = $_POST['response'];

        // Insert the response into the database
        $sql_insert_response = "INSERT INTO responses (message_id, sender_id, response) VALUES (?, ?, ?)";

        try {
            $stmt = $conn->prepare($sql_insert_response);
            if (!$stmt) {
                throw new Exception("Error preparing statement: " . $conn->error);
            }

            $stmt->bind_param("iis", $message_id, $sender_id, $message);
            $stmt->execute();
            echo "Response sent successfully.";
        } catch (Exception $e) {
            echo "Error sending response: " . $e->getMessage();
        }
    } else {
        echo "Error: User ID not set in session.";
    }
}

// Close connection
$conn->close();
?>

