<?php
// Include the database connection file
include 'db_connection.php';

// SQL statement to add "background_check_completed" column to the users table
$addColumnSql = "
    ALTER TABLE users
    ADD COLUMN background_check_completed BOOLEAN DEFAULT FALSE
";

try {
    // Execute the SQL statement
    if ($conn->query($addColumnSql) === TRUE) {
        echo "Column 'background_check_completed' added successfully.";
    } else {
        echo "Error adding column: " . $conn->error;
    }
} catch (Exception $e) {
    echo "Exception occurred: " . $e->getMessage();
}

// Close the database connection
$conn->close();
?>
