<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
    <title>Post Job</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="images/logo3.jpg">
    <link rel="stylesheet" href="styles/main.css">
    <link rel="stylesheet" href="styles/slicknav.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="js/jquery.slicknav.min.js"></script>

	
    <script>
        $(document).ready(function(){
            $('#nav_menu').slicknav({prependTo:"#mobile_menu"});
        });
    </script>
   
</head>
<body>
<header>
        <a href="index.php"><img src="images/logo3.jpg" alt="iHire Logo" ></a>
        <h3>SwiftConnections: Bridging Needs, Building Opportunities</h3>
        <h4>Welcome My Friend!</h4>
        
    </header>
    <nav id="mobile_menu"></nav>
    <nav id="nav_menu">
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="postjob.php">Post Job</a>
                
            </li>
            <li><a href="#">Job Details</a>
                <ul>
                    <li><a href="job_details.php">View Posted Jobs</a> </li>
                    <li><a href="messages.php">View Your Messages</a>
                    </li>
                </ul>
            </li>
            <li><a href="userprofile.php">User Profile</a>
               <!-- <ul>
                    <li><a href="imagemaps/imagemaps.html">Map</a>
                        <ul>
                            <li><a href="https://www.tsa.gov/contact/lost-and-found" target="_blank" rel="noopener noreferrer">TSA lost and found</a></li>
                            <li><a href="https://disneyworld.disney.go.com/guest-services/lost-and-found/" target="_blank" rel="noopener noreferrer">Disney world lost and found</a></li>
                        </ul>
                    </li>  
                </ul>-->
            </li>
            <li class="lastitem"><a href="process_payment.php">Payments</a>
                <!--<ul>
                    <li><a href="twotiernav.html">Finding Lost Items</a></li>
                    <li><a href="twotiernav.html">Preventing Loss</a></li>
                </ul>-->
            </li> 
            
            
            
        </ul>
    </nav>
 <form method="post" action="process_payment.php">
    <input type="hidden" name="receiver_id" value="<?php echo $poster_id; ?>">
    <label for="amount">Amount ($):</label>
    <input type="number" id="amount" name="amount" required>
    <button type="submit">Pay Now</button>
</form>
    
 
</body>
</html>



<?php
session_start();
include 'db_connection.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirect to login page if not logged in
    exit();
}

$user_id = $_SESSION['user_id'];

// Check if the form was submitted and necessary data is provided
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['receiver_id']) && isset($_POST['amount'])) {
        $receiver_id = $_POST['receiver_id']; // ID of the user receiving the payment
        $amount = $_POST['amount']; // Amount to be transferred
    } else {
        echo "Error: Required payment information is missing.";
        exit();
    }
} else {
    echo "Error: Invalid form submission.";
    exit();
}

try {
    // Database connection
    $dsn = "mysql:host=$host;dbname=$dbname;charset=$charset";
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);

    // Retrieve payer's payment information
    $stmt = $pdo->prepare("SELECT p.card_number, p.expiry_date, u.email 
                           FROM payments p 
                           JOIN users u ON p.user_id = u.id 
                           WHERE u.id = ?");
    $stmt->execute([$user_id]);
    $payer = $stmt->fetch();

    // Retrieve receiver's payment information
    $stmt = $pdo->prepare("SELECT p.card_number, p.expiry_date, u.email 
                           FROM payments p 
                           JOIN users u ON p.user_id = u.id 
                           WHERE u.id = ?");
    $stmt->execute([$receiver_id]);
    $receiver = $stmt->fetch();

    if (!$payer || !$receiver) {
        echo "Error: Unable to retrieve payment information.";
        exit();
    }

    // Example: Processing payment (this is a placeholder and not a real payment gateway)
    $transaction_id = uniqid('txn_', true);
    $status = "Success"; // Assuming the payment was successful

    // Save the transaction to the database
    $stmt = $pdo->prepare("INSERT INTO transactions (transaction_id, payer_id, receiver_id, amount, status, created_at) 
                           VALUES (?, ?, ?, ?, ?, NOW())");
    $stmt->execute([$transaction_id, $user_id, $receiver_id, $amount, $status]);

    echo "Payment of $$amount from " . $payer['email'] . " to " . $receiver['email'] . " was successful. Transaction ID: $transaction_id.";

} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>



