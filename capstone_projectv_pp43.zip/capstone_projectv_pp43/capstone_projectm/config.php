<?php
session_start();
include 'db_connection.php'; 

define('PAYPAL_CLIENT_ID', 'AX5LOI7bDCBn5XJVhy4SwZVihemHZJY9OYrDTnJxVyCbd8whkG7yTWXCZU_-2GeAQcGT6MQtkeX_ddPQ
');
define('PAYPAL_SECRET', 'EBjtnaWJbwogtXd-XLJGnx_GcEddpeWZDNG6AQ4xV9rFesEhFNFbguU0LdH1YFR9qOywoD8o3dnKhnZg
');
define('PAYPAL_WEBHOOK_ID', '9DN0453575880571V');
?>
