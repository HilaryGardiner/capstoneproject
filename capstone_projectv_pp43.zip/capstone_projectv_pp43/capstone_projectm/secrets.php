<?php
// Keep your Stripe API key protected by including it as an environment variable
// or in a private script that does not publicly expose the source code.

// This is your test secret API key.
$stripeSecretKey = 'sk_test_51Q37KRCBRQoEuYRBE9c5MQb4yGp0xtMAOT5xJzUKum0WDfpeLqX0KDFRKXc0XMHGsX7iumtwqrHYz5lg1a82WwZq00qWa5ZMLh';