// webhook.php

<?php
include 'db_connection.php'; // Include the database connection file

// Read raw JSON data from the incoming webhook request
$rawData = file_get_contents('php://input');

// Decode JSON data into an associative array
$event = json_decode($rawData, true);

// Log the received webhook data into a file for debugging purposes
file_put_contents('paypal_webhook_logs.txt', $rawData . PHP_EOL, FILE_APPEND);

// Check if the event type is a successful PayPal payment capture
if ($event['event_type'] === 'PAYMENT.CAPTURE.COMPLETED') {
    // Extract transaction details from the event data
    $transactionID = $event['resource']['id']; // PayPal transaction ID
    $accountID = $event['resource']['payee']['email_address']; // Payee's email address
    $amount = $event['resource']['amount']['value']; // Transaction amount
    $status = $event['resource']['status']; // Payment status

    // Update the payment status in the database for the given transaction ID
    $stmt = $conn->prepare("UPDATE payments SET status=? WHERE transaction_id=?");
    $stmt->bind_param("ss", $status, $transactionID);
    $stmt->execute();
    $stmt->close(); // Close the statement
}

// Respond with HTTP 200 OK to acknowledge receipt of the webhook event
http_response_code(200);
?>
