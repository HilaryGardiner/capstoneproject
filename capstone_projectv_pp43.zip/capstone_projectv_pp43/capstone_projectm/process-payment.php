<?php
include 'db_connection.php'; // Include the database connection file

header("Content-Type: application/json"); // Set response type to JSON

// Retrieve JSON input from the request body and decode it into an associative array
$input = json_decode(file_get_contents("php://input"), true);

// Validate that all required fields are present in the request
if (!isset($input['transaction_id'], $input['account_id'], $input['amount'], $input['status'])) {
    http_response_code(400); // Return HTTP 400 Bad Request if any field is missing
    echo json_encode(['error' => 'Invalid request parameters.']);
    exit; // Stop further execution
}

// Assign received data to variables
$transactionID = $input['transaction_id'];
$accountID = $input['account_id'];
$amount = $input['amount'];
$status = $input['status'];

// Prepare SQL statement to insert payment details into the database
$stmt = $conn->prepare("INSERT INTO payments (transaction_id, account_id, amount, status) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssds", $transactionID, $accountID, $amount, $status); // Bind values to prevent SQL injection

// Execute the statement and send a JSON response based on success or failure
if ($stmt->execute()) {
    echo json_encode(['message' => 'Payment recorded successfully!']); // Success response
} else {
    echo json_encode(['error' => 'Database error. Payment not recorded.']); // Failure response
}

// Close the statement and database connection
$stmt->close();
$conn->close();
?>

