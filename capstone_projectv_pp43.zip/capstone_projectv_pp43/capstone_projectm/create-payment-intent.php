<?php

include 'db_connection.php'; // Your database connection file
require __DIR__ . '/vendor/autoload.php';
require __DIR__ . '/config.php'; // Secure API keys

header("Content-Type: application/json");

\Stripe\Stripe::setApiKey(STRIPE_SECRET_KEY);

$rawInput = file_get_contents('php://input');
error_log("Received Input: " . $rawInput);
$input = json_decode($rawInput, true);

if (json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON format.']);
    exit;
}

if (!isset($input['account_id'], $input['amount'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing parameters.']);
    exit;
}

$accountID = filter_var($input['account_id'], FILTER_SANITIZE_STRING);
$amount = filter_var($input['amount'], FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);

if (!$accountID || !$amount) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid request parameters.']);
    exit;
}

// Validate the Stripe account dynamically
try {
    $account = \Stripe\Account::retrieve($accountID);
    if (!$account->payouts_enabled || !$account->charges_enabled) {
        throw new Exception("Account is not eligible to receive payments.");
    }
} catch (\Stripe\Exception\ApiErrorException $e) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid or inactive Stripe account.']);
    exit;
}

try {
    $platformFee = round($amount * 0.03);

    $paymentIntent = \Stripe\PaymentIntent::create([
        'amount' => $amount,
        'currency' => 'usd',
        'payment_method_types' => ['card'],
        'application_fee_amount' => $platformFee,
        'transfer_data' => ['destination' => $accountID],
    ]);

    echo json_encode(['clientSecret' => $paymentIntent->client_secret]);
} catch (\Stripe\Exception\ApiErrorException $e) {
    error_log($e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Payment processing failed. Try again.']);
}
?>

