<?php 
session_start(); // Start the session to manage user sessions
include 'db_connection.php'; // Include the database connection file
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PayPal Payment</title>
    <!-- Include PayPal SDK with your client ID and currency set to USD -->
    <script src="https://www.paypal.com/sdk/js?client-id=AX5LOI7bDCBn5XJVhy4SwZVihemHZJY9OYrDTnJxVyCbd8whkG7yTWXCZU_-2GeAQcGT6MQtkeX_ddPQ&currency=USD"></script> 
</head>
<body>
    <h1>Service Payment</h1>

    <!-- Payment form where users enter recipient's PayPal email and payment amount -->
    <form id="payment-form">
        <label for="account_id">Service Provider PayPal Email:</label>
        <input type="email" id="account_id" name="account_id" required>
        <br><br>

        <label for="amount">Payment Amount (USD):</label>
        <input type="number" id="amount" name="amount" min="1" step="0.01" required>
        <br><br>

        <!-- PayPal button container where the payment button will be rendered -->
        <div id="paypal-button-container"></div> 
    </form>

    <script>
    paypal.Buttons({
        createOrder: function(data, actions) {
            const amount = parseFloat(document.getElementById('amount').value);

            if (isNaN(amount) || amount <= 0) {
                alert('Invalid input: Check Payment Amount.');
                return actions.reject();
            }

            return actions.order.create({
                purchase_units: [{
                    amount: { value: amount.toFixed(2) }
                }]
            });
        },
        onApprove: function(data, actions) {
            return actions.order.capture().then(function(details) {
                fetch('/process-payment.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        transaction_id: details.id,
                        account_id: document.getElementById('account_id').value.trim(), 
                        amount: details.purchase_units[0].amount.value,
                        status: details.status
                    })
                }).then(response => response.json())
                  .then(data => alert(data.message))
                  .catch(error => console.error('Error:', error));
            });
        },
        onError: function(err) {
            console.error('PayPal Checkout Error:', err);
            alert('Payment failed. Please try again.');
        }
    }).render('#paypal-button-container');
</script>
</body>
</html>
