<?php // Example 04: index.php
  session_start(); //sets up a session that will remember certain values we want stored across different PHP files
                   //It represents a visit by a user to the site; can time out if the user ignores the site for a period of time


  require_once 'header.php';

  echo "<div class='center'>Welcome to immediateHire,";

  if ($loggedin) echo " $user, you are logged in";
  else           echo ' please sign up or log in';

  echo <<<_END
      </div><br>
    </div>
    <div data-role="footer">
      <h4>Web App from <i><a href='https://github.com/RobinNixon/lpmj6'
      target='_blank'>Learning PHP MySQL & JavaScript</a></i></h4>
    </div>
  </body>
</html>
_END;
?>
