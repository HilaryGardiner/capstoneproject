// Example 14: javascript.js

// This function, named "O", takes a parameter "i" which could be an element ID or an object.
// It checks if the type of "i" is 'object'. If it is, then it returns "i" as is (assuming it's already an object).
// If the type of "i" is not 'object', it assumes "i" is an element ID and tries to fetch the element using document.getElementById().
function O(i) { 
    return typeof i == 'object' ? i : document.getElementById(i);
}

// This function, named "S", takes a parameter "i" which could be an element ID or an object.
// It uses the previously defined function "O(i)" to fetch the element (or object) referred to by "i",
// and then accesses the "style" property of that element/object and returns it.
function S(i) {
    return O(i).style;
}

// This function, named "C", takes a parameter "i" which is a class name.
// It uses the document.getElementsByClassName() method to retrieve a collection of elements
// that have the given class name "i", and returns this collection.
function C(i) {
    return document.getElementsByClassName(i);
}
