<?php // Example 08: profile.php
  require_once 'header.php';

  if (!$loggedin) die("</div></body></html>");

  echo "<h3>Your Profile</h3>";

  $result = queryMysql("SELECT * FROM profiles WHERE user='$user'");
    
  if (isset($_POST['text'])) //Checks whether some text was posted to the program.
  {
    $text = sanitizeString($_POST['text']); //sanitizes program.
    $text = preg_replace('/\s\s+/', ' ', $text); //All long whitespace sequences are replaced with single spaces.

    if ($result->rowCount())
         queryMysql("UPDATE profiles SET text='$text' where user='$user'");
    else queryMysql("INSERT INTO profiles VALUES('$user', '$text')");
  }
  else
  {
    if ($result->rowCount())
    {
      $row  = $result->fetch();
      $text = stripslashes($row['text']);
    }
    else $text = "";
  }

  $text = stripslashes(preg_replace('/\s\s+/', ' ', $text));

  if (isset($_FILES['image']['name'])) //Checks to see whether an image has been uploaded.
  {
    $saveto = "$user.jpg";
    move_uploaded_file($_FILES['image']['tmp_name'], $saveto);
    $typeok = TRUE;

    switch($_FILES['image']['type'])
    {
      case "image/gif":   $src = imagecreatefromgif($saveto); break;
      case "image/jpeg":  // Both regular and progressive jpegs
      case "image/pjpeg": $src = imagecreatefromjpeg($saveto); break;
      case "image/png":   $src = imagecreatefrompng($saveto); break;
      default:            $typeok = FALSE; break; //if image is not of allowed type, type selection is set to false, preventing 
    }                                             //selection.

    if ($typeok)
    {
      list($w, $h) = getimagesize($saveto); //Assigning values from an array to separate variables. 

      $max = 400; //New image of same ratio but with no dimension greater than 400 pixels.
      $tw  = $w;
      $th  = $h;

      if ($w > $h && $max < $w)
      {
        $th = $max / $w * $h;
        $tw = $max;
      }
      elseif ($h > $w && $max < $h)
      {
        $tw = $max / $h * $w;
        $th = $max;
      }
      elseif ($max < $w)
      {
        $tw = $th = $max;
      }

      $tmp = imagecreatetruecolor($tw, $th); //create a new, blank canvas $tw wide and $th high in $tmp.
      imagecopyresampled($tmp, $src, 0, 0, 0, 0, $tw, $th, $w, $h); //Called to resample the image from $src to the new $tmp.
      //Resample image could be blurry so 'imageconvolution' function sharpens the image up a bit.
      imageconvolution($tmp, array(array(-1, -1, -1),
        array(-1, 16, -1), array(-1, -1, -1)), 8, 0);
      imagejpeg($tmp, $saveto); //image is saved as .jpeg file in the location defined by the variable $saveto.
      imagedestroy($tmp); //Remove both the original and the resized image canvases, return memory that was used.
      imagedestroy($src);
    }
  }

  showProfile($user);
  
  //"enctype='multipart/form-data" allows us to send more than one type of data at a time
  //enabling the posting of an image as well as some text.

echo <<<_END
      <form data-ajax='false' method='post'
        action='profile.php?r=$randstr' enctype='multipart/form-data'> 
      <h3>Enter or edit your details and/or upload an image</h3>
      <textarea name='text'>$text</textarea><br>
      Image: <input type='file' name='image' size='14'> <!--'input type='file' create browser button to upload files-->
      <input type='submit' value='Save Profile'>
      </form>
    </div><br>
  </body>
</html>
_END;
?>
